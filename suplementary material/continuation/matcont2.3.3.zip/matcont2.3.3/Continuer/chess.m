function h=chess(odefile,jacobian,hessians,x,p)
global cds
nphase=size(x,1);
if cds.options.SymDerivative >= 2
  h = feval(hessians, 0, x, p{:});
else
  for i=1:nphase
    x1 = x; x1(i) = x1(i)-cds.options.Increment;
    x2 = x; x2(i) = x2(i)+cds.options.Increment;
    h(:,:,i) = cjac(odefile,jacobian,x2,p)-cjac(odefile,jacobian,x1,p);
  end
  h = h/(2*cds.options.Increment);
end
