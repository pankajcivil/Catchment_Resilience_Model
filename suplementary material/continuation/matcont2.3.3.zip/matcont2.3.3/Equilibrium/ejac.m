function j=ejac(x,p)
global eds cds
if (cds.options.SymDerivative >=1)
  j = feval(eds.Jacobian, 0, x, p{:});
else
  for i=1:(cds.ndim-length(eds.ActiveParams))
    x1 = x; x1(i) = x1(i)-cds.options.Increment;
    x2 = x; x2(i) = x2(i)+cds.options.Increment;
    j(:,i) = feval(eds.func, 0, x2, p{:})-feval(eds.func, 0, x1, p{:});
  end
  j = j/(2*cds.options.Increment);
end
