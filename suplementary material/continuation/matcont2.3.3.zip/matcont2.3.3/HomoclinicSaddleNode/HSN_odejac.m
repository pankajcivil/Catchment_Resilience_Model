function j=HSN_odejac(x,p)
global hsnds cds
if cds.options.SymDerivative >= 1
  j = feval(hsnds.Jacobian, 0, x,p{:});
else
  for i=hsnds.phases
    x1 = x; x1(i) = x1(i)-cds.options.Increment;
    x2 = x; x2(i) = x2(i)+cds.options.Increment;
    j(:,i) = feval(hsnds.func, 0, x2, p{:})-feval(hsnds.func, 0, x1, p{:});
  end
  j = j/(2*cds.options.Increment);
end
