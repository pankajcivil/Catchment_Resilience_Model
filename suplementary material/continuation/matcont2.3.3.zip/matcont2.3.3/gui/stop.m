function varargout = stop(varargin)
% STOP Application M-file for stop.fig
%    FIG = STOP launch stop GUI.
%    STOP('callback_name', ...) invoke the named callback.

% Last Modified by GUIDE v2.0 05-Feb-2002 09:50:26
global driver_window calculation_progress
if nargin == 0  % LAUNCH GUI

	fig = openfig(mfilename,'reuse');
    % Generate a structure of handles to pass to callbacks, and store it. 
	handles = guihandles(fig);
	guidata(fig, handles);
    driver_window = fig;
	if nargout > 0
		varargout{1} = fig;
	end

elseif ischar(varargin{1}) % INVOKE NAMED SUBFUNCTION OR CALLBACK

	try
		[varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
	catch
		errordlg(lasterr,mfilename);
        if ishandle(driver_window)
            delete(driver_window);   
        end
	end

end
% --------------------------------------------------------------------
function varargout = resume_Callback(h, eventdata, handles, varargin)
global driver_window calculation_progress gds;
    
    set(driver_window,'Userdata',[0]);
    calculation_progress = 1;

%-------------------------------------------------------------------
function varargout = pause_Callback(h, eventdata,handles,varargin)
global driver_window calculation_progress gds;
    set(driver_window,'UserData',[1]);
    calculation_progress = 2;

%-------------------------------------------------------------------
function varargout = stop_Callback(h, eventdata,handles,varargin)
global driver_window calculation_progress gds;
    set(driver_window,'UserData',[0]);
    calculation_progress = 0;

%-------------------------------------------------------------------
function varargout = teststop(h)
global driver_window calculation_progress
    if isempty(driver_window)|calculation_progress==0
        return
    end
    key = double(get(h,'Currentcharacter'));
    if isempty(key),return;end
    switch key
    case 27% press Esc to stop
        stop('stop_Callback',driver_window,[],[]);  
    case 13%press Enter to pause
        stop('pause_Callback',driver_window,[],[]);    
    case 32%press Space bar to resume
        stop('resume_Callback',driver_window,[],[]);    
    end