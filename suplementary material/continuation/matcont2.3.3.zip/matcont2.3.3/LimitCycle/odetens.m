function h=odetens(x,p)
global lds cds

if cds.options.SymDerivative >= 3
  h = feval(lds.Der3, 0, x, p{:});
else
  for i=lds.phases
    x1 = x; x1(i) = x1(i)-cds.options.Increment;
    x2 = x; x2(i) = x2(i)+cds.options.Increment;
    h(:,:,:,i) = odehess(x2,p)-odehess(x1,p);
  end
  h = h/(2*cds.options.Increment);
end
