function S = testcont(J)

% calculate multipliers
global lds
% sizeJ=size(J)
q = size(J,1);
r2 = q-1:q;
r1 = lds.phases;
r = lds.col_coords;
% i2 = r;
S = sparse(q,q,lds.ncoords*(4+lds.nphase)+(lds.ncol_coord)/3+lds.nphase);
for i = lds.tsts
  p = speye(lds.ncol_coord);  
  sJ = J(r,lds.nphase+r);
  [sl,su] = lu(sJ);
  p = inv(sl);
  S(r,[r1 r2]) = p*J(r,[r1 r2]);
  S(r,r+lds.nphase) = su;
  r = r+lds.ncol_coord;
  r1 = r1+lds.ncol_coord;
%   i2 = i2+lds.ncol_coord;
end
S(end-lds.nphase-1:end,:) = J(end-lds.nphase-1:end,:);
a = (1:lds.ntst-1)*(lds.ncol*lds.nphase);b=[];
for j=1:size(a,2)
   b = [b a(j)+lds.phases];
end
% full(S)
c = (lds.nphase+1):(lds.ncoords-lds.nphase);
[tf,loc] = ismember(c,b);c(find(loc))=[];

for i=1:lds.nphase:size(c,2)
     r = c(i-1+lds.phases);
     for j=r
         f = S(end-1:end,j)/S(j-lds.nphase,j);
         S(end-1:end,:) = S(end-1:end,:)-f*S(j-lds.nphase,:);
     end
end
% full(S)

for i = 1:lds.nphase:(lds.ntst-1)*lds.nphase
    r = b(i-1+lds.phases);
    for j = r
        r1 = r+((lds.ncol-1)*lds.nphase);
        f = S(r1,j)/S(j-lds.nphase,j);
        S(r1,:) = S(r1,:)-f*S(j-lds.nphase,:);
         f = S(end-1:end,j)/S(j-lds.nphase,j);
         S(end-1:end,:) = S(end-1:end,:)-f*S(j-lds.nphase,:);
    end
end
% full(S)

