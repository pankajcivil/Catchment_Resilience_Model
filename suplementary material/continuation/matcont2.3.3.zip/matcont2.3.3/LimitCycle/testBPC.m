function testBPC(J)

% calculate multipliers
global lds
q = size(J,1);
r2 = q-1:q;
r = lds.col_coords;
r1 = lds.phases;
for i = lds.tsts
  sJ = J(r,lds.nphase+r);
  [sl,su] = lu(sJ);
  p = inv(sl);
  J(r,[r1 r2]) = p*J(r,[r1 r2]);
  i4 = r(lds.phases)+lds.nphase;
  J(r,r+lds.nphase) = su;
  for j=1:lds.ncol-1
      for j=i4
         f = J(end-1:end,j)/J(j-lds.nphase,j);
         J(end-1:end,:) = J(end-1:end,:)-f*J(j-lds.nphase,:);
      end
      i4 = i4+lds.nphase;
  end
  r1 = r1+lds.ncol_coord;
  r  = r+lds.ncol_coord;
end
S = J([lds.multi_r1 q-lds.nphase-1:q],[lds.multi_r2 q-1:q]);
for i = (1:(lds.ntst-1))*lds.nphase
    r = i+lds.phases;
    for j = r
        f = S(r,j)/S(j-lds.nphase,j);
        S(r,:) = S(r,:)-f*S(j-lds.nphase,:);
        f = S(end-1:end,j)/S(j-lds.nphase,j);
        S(end-1:end,:) = S(end-1:end,:)-f*S(j-lds.nphase,:);
    end
end
A  = [S(end-2*lds.nphase-1:end,lds.phases) S(end-2*lds.nphase-1:end,end-lds.nphase-1:end)];
A0 = full(S(end-1-2*lds.nphase:end-2-lds.nphase,lds.phases));
A1 = full(S(end-1-2*lds.nphase:end-2-lds.nphase,end-lds.nphase-1:end-2));
lds.monodromy = -A1\A0;
deta  =  det(A);
lds.testBPC = deta;
