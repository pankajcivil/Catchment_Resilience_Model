function j = bpjacbr(x,p)
global bpds cds

if cds.options.SymDerivativeP >= 1
  j = feval(bpds.JacobianP, 0, x, p{:});
  j = j(:,bpds.BranchParam);
else
    i=bpds.BranchParam;
    p1 = p; p1{i} = p1{i}-cds.options.Increment;
    p2 = p; p2{i} = p2{i}+cds.options.Increment;
    j(:,1) = feval(bpds.func, 0, x,  p2{:})-feval(bpds.func, 0, x, p1{:});
    j = j/(2*cds.options.Increment);
    j=j(:,1);
end
