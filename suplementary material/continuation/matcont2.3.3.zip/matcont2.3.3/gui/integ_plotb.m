function status = integ_plot(t,y,flag,varargin)
%    integ_plot  2and3-D phase plane ODE output function.
%   When the function is passed to an ODE solver as the 'OutputFcn'
%   property, i.e. options = odeset('OutputFcn',@odephas2), the solver
%   calls ODEPHAS2(T,Y,'') after every timestep.     
%   At the start of integration, a solver calls INTEG_PLOT(TSPAN,Y0,'init') to
%   initialize the output function.  After each integration step to new time
%   point T with solution vector Y the solver calls STATUS = INTEG_PLOT(T,Y,'').
%   If the solver's 'Refine' property is greater than one (see ODESET), then
%   T is a column vector containing all new output times and Y is an array
%   comprised of corresponding column vectors.  The STATUS return value is 1
%   if the STOP button has been pressed and 0 otherwise.  When the
%   integration is complete, the solver calls INTEG_PLOT([],[],'done').

  
global gds sys ud MC driver_window calculation_progress string_O;
status = 0;
switch flag
    case '' % odephas2(t,y) [v5 syntax] or odephas2(t,y,'')
    if calculation_progress==0
       status = 1;
    else 
       status = 0;
    end;
    if calculation_progress==2
        set(MC.mainwindow.mstatus,'String','pause');
        waitfor(driver_window,'UserData',[0]);
        set(MC.mainwindow.mstatus,'String','computing');
    end;
     if size(MC.D2,2)>0
            for siz=1:size(MC.D2,2)
                dat=[];
                dat = get(MC.D2(siz),'UserData');
                ux = get(dat.traj,'XData');
                uy = get(dat.traj,'YData');
                s1=eval(dat.label{1});
                s2=eval(dat.label{2});
                set(dat.traj,'XData',[ux s1],'YData',[uy s2]);
                drawnow;   
            end
        end
        if size(MC.D3,2)>0
            for siz=1:size(MC.D3,2)
                dat=[];
                dat = get(MC.D3(siz),'UserData');
                ux = get(dat.traj,'XData');
                uy = get(dat.traj,'YData');
                uz = get(dat.traj,'ZData');
                s1 = eval(dat.labe1{1});
                s2 = eval(dat.label{2});
                s3 = eval(dat.label{3});
                set(dat.traj,'XData',[ux s1'],'YData',[uy s2'],'ZData', [uz s3']);
                drawnow;   
            end
        end
        if ~isempty(MC.numeric_fig)%numeric window is open
            y=ud.y(newi,:)';
            t=ud.t(newi);
            dat = get(MC.numeric_fig,'Userdata');
            for k=1:size(dat.label,2)
                eval(dat.label{k});  
            end
        end   
    case 'init'                           % odephas2(tspan,y0,'init')
        string_O=feval('O','load_draw');
        ud = [];
        % The STOP button.        
       for i=1:gds.dim,x(i,1)=0;end;    
        if size(MC.D2,2)>0
            for siz=1:size(MC.D2,2)
                dat=[];
                dat = get(MC.D2(siz),'UserData');
                %ud.nr = dat.nr;
                nr=dat.nr;
                if isempty(strmatch(char(gds.plot2(nr,1).type),string_O,'exact'))|isempty(strmatch(char(gds.plot2(nr,2).type),string_O,'exact'))
                    dat.p2=[inf inf];
                else
                    dat.p2 =feval(deblank(gds.type),'make_ready',gds.plot2(nr,:),x);           
                end
                dat.label{1}='empt';dat.label{2}='empt';
                for k=1:2
                    if dat.p2(1,k)<0        
                        pl2=-(dat.p2(1,k));
                        dat.label{k} = sprintf('gds.parameters{%d,2}',pl2);
                    end                 
                    if dat.p2(1,k)==0
                        dat.label{k} ='t';
                    end
                    if strcmp(dat.label{k},'empt')==1       
                        dat.label{k} = sprintf('y(%d,:)',dat.p2(1,k));
                    end
                end
                Xp = eval(dat.label{1});
                Yp = eval(dat.label{2});
                dat.traj = line(0,0,'EraseMode','none');
                set(dat.traj,'XData',[],'YData',[]);
                set(MC.D2(siz),'UserData',dat); 
                xlabel(gds.plot2(nr,1).label);ylabel(gds.plot2(nr,2).label);
            end
        end
        if size(MC.D3,2)>0
            ud.p3 = [];
            for siz=1:size(MC.D3,2)
                dat = get(MC.D3(siz),'UserData');
                ud.nr = dat.nr;nr=dat.nr;
                if isempty(strmatch(char(gds.plot3(nr,1).type),string_O,'exact'))|isempty(strmatch(char(gds.plot3(nr,2).type),string_O,'exact'))|isempty(strmatch(char(gds.plot3(nr,3).type),string_O,'exact'))
                    ud.p3=[inf inf inf];
                else
                    ud.p3 =feval(deblank(gds.type),'make_ready',gds.plot3(nr,:),x);           
                end
                ud.label{1}='empt';ud.label{2}='empt';ud.label{3} = 'empt';
                for k=1:3
                    if ud.p3(1,k)<0        
                        pl3=-(ud.p3(1,k));
                        ud.label{k}=sprintf('gds.parameters{%d,2}',pl3);
                    end   
                    if ud.p3(1,k)==0
                        ud.label{k}='t';
                    end
                    if strcmp(ud.label{k},'empt')==1       
                        ud.label{k}=sprintf('y(:,%d)',ud.p3(1,k));                
                    end
                end   
                Xp = eval(ud.label{1});
                Yp = eval(ud.label{2});
                Zp = eval(ud.label{3});
                ud.traj = line(Xp,Yp,Zp,'EraseMode','none');
                set(ud.traj,'XData',[],'YData',[],'ZData',[]);
                set(MC.D3(siz),'UserData',ud);
                xlabel(gds.plot3(nr,1).label); ylabel(gds.plot3(nr,2).label);zlabel(gds.plot3(nr,3).label);
            end
        end
        if size(MC.D2,2)>0 %2D window open
            d=get(MC.D2,'UserData');
            if ~(size(MC.D2,2)==1),d=vertcat(d{:,1});end
            da=vertcat(d.p2);
            hel=find(da(:,1)==inf);
            MC.D2(hel)=[];
            if isempty(MC.D2),MC.D2=[];end
        end
        if size(MC.D3,2)>0%3D window open
            d=get(MC.D3,'UserData');   
            if ~(size(MC.D3,2)==1),d=vertcat(d{:,1});end
            da=vertcat(d.p3);        
            hel=find(da(:,1)==inf);MC.D3(hel)=[];
            if isempty(MC.D3),MC.D3=[];end
        end
        if ~isempty(MC.numeric_fig)
            ud.label{1}='';
            num = 1;
            if isfield(MC.numeric_handles,'coord1')
                for k=1:size(y,2)
                    for d=1:gds.dim
                        ud.label{num}=sprintf('set(MC.numeric_handles.coord%d,''String'',y(%d,%d))',d,d,k);
                        num = num+1;
                    end
                end
            end
            if isfield(MC.numeric_handles,'time')
                ud.label{num}=sprintf('set(MC.numeric_handles.time,''String'',t(%d,1))',k);          
                num = num+1;
            end
            if isfield(MC.numeric_handles,'param1')
                for d=1:size(gds.parameters,1)
                   ud.label{num}=sprintf('set(MC.numeric_handles.param%d,''String'',gds.parameters{%d,2})',d,d);
                   num = num+1;
                end 
            end
            set(MC.numeric_fig,'Userdata',ud);
        end
        set(MC.mainwindow.mstatus,'String','computing');
        stop;

    case 'done'         % integ_plot([],[],'done')  
        status=1;
%         newi = ud.i;      
%         if size(MC.D2,2)>0
%             for siz=1:size(MC.D2,2)
%                 dat=[];
%                 dat = get(MC.D2(siz),'UserData');
%                 ux=get(dat.traj,'XData');
%                 uy=get(dat.traj,'YData');
%                 s1=eval(dat.label{1});
%                 s2=eval(dat.label{2});
%                 set(dat.traj,'XData',[ux s1'],'YData',[uy s2']);
%                 drawnow;   
%             end
%         end
%         if size(MC.D3,2)>0
%             for siz=1:size(MC.D3,1)
%                 dat=[];
%                 dat = get(MC.D3(siz),'UserData');
%                 for k=1:3
%                     ux = get(dat.traj,'XData');
%                     uy = get(dat.traj,'YData');
%                     uz = get(dat.traj,'ZData');
%                     s1 = eval(dat.label{1});
%                     s2 = eval(dat.label{2});
%                     s3 = eval(dat.label{3});
%                     set(dat.traj,'XData',[ux s1'],'YData',[uy s2'],'ZData',[uz s3']);
%                     drawnow;   
%                 end
%             end
%         end        
%         if ~isempty(MC.numeric_fig)%numeric window is open
%             y = ud.y(newi,:)';
%             t = ud.t(newi);
%             dat = get(MC.numeric_fig,'Userdata');
%             for k=1:size(dat.label,2)
%                 eval(dat.label{k});  
%             end
%         end
%         if size(MC.D2,2)>0
%             ud = get(MC.D2,'UserData');
%             if (size(MC.D2,2)~=1),ud=vertcat(ud{:,1});end
%             ud = rmfield(ud,{'t','y','i','label'});
%             for k=1:size(MC.D2,2)
%                 set(MC.D2(k),'UserData',ud(k));
%             end
%         elseif size(MC.D3,2)>0
%             ud = get(MC.D3,'UserData');
%             if (size(MC.D3,2)~=1),ud=vertcat(ud{:,1});end
%             ud = rmfield(ud,{'t','y','i','label'});
%             for k=1:size(MC.D3,2)
%                 set(MC.D3(k),'UserData',ud(k));
%             end
%         end                   
        set(MC.mainwindow.mstatus,'String','ready');
        if ishandle(driver_window),delete(driver_window);end
    end
end
drawnow;