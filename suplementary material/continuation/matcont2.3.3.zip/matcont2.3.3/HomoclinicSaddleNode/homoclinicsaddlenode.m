function out = homoclinicsaddlenode
%
% homoclinic curve definition file for a problem in odefile
% 
global hsnds cds
    out{1}  = @curve_func;
    out{2}  = @defaultprocessor;
    out{3}  = @options;
    out{4}  = @jacobian;
    out{5}  = @hessians;
    out{6}  = @testf;
    out{7}  = @userf;
    out{8}  = @process;
    out{9}  = @singmat;
    out{10} = @locate;
    out{11} = @init;
    out{12} = @done;
    out{13} = @adapt;
return


%----------------------------------------------------

function func = curve_func(arg)

  [x,x0,p,T,eps0,eps1,YS,YU] = rearr(arg);
  func = BVP_HSN(x,x0,p,T,eps0,eps1,YS,YU);
  
%------------------------------------------------------

function varargout = jacobian(varargin)

global hsnds cds

  [x,x0,p,T,eps0,eps1,YS,YU] = rearr(varargin{1});
  varargout{1} = BVP_HSN_jac(hsnds.func,x,x0,p,T,eps0,eps1,YS,YU);
  
%-----------------------------------------------------

function varargout = hessians(varargin)

%------------------------------------------------------

function varargout = defaultprocessor(varargin)
global hsnds opt cds

  [x,x0,p,T,eps0,eps1,YS,YU] = rearr(varargin{1});
  if  size(varargin{1}) ==   size(varargin{2})
      v = rearr(varargin{2});
  end
  
  % update
  if ~isempty(hsnds.ups)
    hsnds.upold = hsnds.ups;
  end
  hsnds.ups = reshape(x,hsnds.nphase,hsnds.tps);
  hsnds.vps = reshape(v,hsnds.nphase,hsnds.tps);
  % update upoldp
  p1 = num2cell(p);
  for i=1:hsnds.tps
    hsnds.upoldp(:,i) = 2*T*feval(hsnds.func, 0, hsnds.ups(:,i), p1{:});
  end
  hsnds.eps0 = eps0;
  hsnds.eps1 = eps1;
  hsnds.YS = YS;
  hsnds.YU = YU;
  hsnds.T = T;
  hsnds.x0 = x0;
  
% Update dimensions
% -----------------
p = num2cell(p);
  A = HSN_odejac(x0,p);
D = eig(A);
% nneg = dimension of stable subspace
[y,i] = min(abs(D));
hsnds.nneg = sum(real(D) < 0);
hsnds.npos = sum(real(D) > 0);
if (hsnds.nneg+hsnds.npos == hsnds.nphase) && (D(i) < 0)
    hsnds.nneg = hsnds.nneg-1;
elseif (hsnds.nneg+hsnds.npos == hsnds.nphase)
    hsnds.npos = hsnds.npos-1;
end
hsnds.Ysize = (hsnds.nneg+1)*hsnds.npos + hsnds.nneg*(hsnds.npos+1);
  
% Normalize bases
% ---------------
  if nargin > 2
    % set data in special point structure
    s = varargin{3};
    s.data.timemesh = hsnds.msh;
    s.data.ntst = hsnds.ntst;
    s.data.ncol = hsnds.ncol;
    s.data.parametervalues = p;
    s.data.T = T;
    varargout{3} = s;
  end
  % all done succesfully
  varargout{1} = 0;
  varargout{2} = hsnds.msh';
  
  if (cds.options.Eigenvalues==1)
      varargout{2} = [varargout{2}; D];
  end

%-------------------------------------------------------
  
function option = options
global hsnds cds
  % Check for symbolic derivatives in odefile
  
  symjac  = ~isempty(hsnds.Jacobian);
  symhes  = ~isempty(hsnds.Hessians);
  symtens3 = ~isempty(hsnds.Der3);
  symtens4 = ~isempty(hsnds.Der4);
  symtens5 = ~isempty(hsnds.Der5);
  
  symord = 0; 
  if symjac, symord = 1; end
  if symhes, symord = 2; end
  if symtens3, symord = 3; end
  if symtens4, symord = 4; end
  if symtens5, symord = 5; end

  option = contset;
%   switch hsnds.nphase
%       case 1
%           option=contset(option,'IgnoreSingularity',[2 3 4]);
%       case 2
%           option=contset(option,'IgnoreSingularity',[4]);
%   end
  option = contset(option, 'SymDerivative', symord);
  option = contset(option, 'Workspace', 1);
  option = contset(option, 'Locators', [0]);
  symjacp = ~isempty(hsnds.JacobianP); 
  symhes  = ~isempty(hsnds.HessiansP);
  symordp = 0;
  if symjacp, symordp = 1; end
  if symhes,  symordp = 2; end
  option = contset(option, 'SymDerivativeP', symordp);
  
  cds.symjac  = 1;
  cds.symhess = 0;
  
%------------------------------------------------------  
  
function [out, failed] = testf(id, x0, v)
global hsnds 

[x,x0,p,T,eps0,eps1,YS,YU] = rearr(x0);
ups = reshape(x,hsnds.nphase,hsnds.tps);
A = HSN_odejac(x0,num2cell(p));

% Non-Central Homoclinic to saddle-node
opts.disp = 0;
% [V,D] = eigs(A',1,'SM',opts);
[V,D] = eig(A');
[Y,i] = min(abs(diag(D)));
V = V(:,i);
D = D(i,i);

psi1 = 1/hsnds.T * ((ups(:,1) - x0)' * V);
psi2 = 1/hsnds.T * ((ups(:,end) - x0)' * V);
res(1) = psi1 * psi2;

out = res;
failed = [];

%-------------------------------------------------------------

function [out, failed] = userf(userinf, id, x, v)
global  hsnds
dim =size(id,2);
failed = [];
for i=1:dim
  lastwarn('');
  [x,x0,p,T,eps0,eps1,YS,YU] = rearr(x); p = num2cell(p);
  if (userinf(i).state==1)
      out(i)=feval(hsnds.user{id(i)},0,x0,p{:});
  else
      out(i)=0;
  end
  if ~isempty(lastwarn)
    msg = sprintf('Could not evaluate userfunction %s\n', id(i).name);
    failed = [failed i];
  end
end

%-----------------------------------------------------------------

function [failed,s] = process(id, x, v, s)
global hsnds
[x,x0,p,T,eps0,eps1,YS,YU] = rearr(x);
AP = p(hsnds.ActiveParams);
switch id
    case 1
        fprintf('Non-Central Homoclinic to Saddle-Node, parameters = %g and %g.\n',AP(1),AP(2));
        s.msg  = sprintf('Non-Central Homoclinic to Saddle-Node');
end
failed = 0;

%-------------------------------------------------------------  

function [S,L] = singmat

  S = [ 0 ];
  L = [ 'NCH' ];

%--------------------------------------------------------

function [x,v] = locate(id, x1, v1, x2, v2)
msg = sprintf('No locator defined for singularity %d', id);
error(msg);
    
%----------------------------------------------------------

function varargout = init(varargin)

WorkspaceInit(varargin{1:2});
% all done succesfully
varargout{1} = 0;

%-----------------------------------------------------------

function varargout = done

%-----------------------------------------------------------

function [res,x,v] = adapt(x,v)
global hsnds

cds.adapted = 1;

YU = hsnds.YU;
YS = hsnds.YS;

[x,v] = HSN_adapt_mesh(x,v);

Q0S = hsnds.oldStableQ;
QbS1 = Q0S(:,1:hsnds.nneg);
QbS2 = Q0S(:,hsnds.nneg+1:end);
Q0U = hsnds.oldUnstableQ;
QbU1 = Q0U(:,1:hsnds.npos);
QbU2 = Q0U(:,hsnds.npos+1:end);

[Q1S,S1,R1] = svd(QbS1 + QbS2*YS);
[Q1U,S1,R1] = svd(QbU1 + QbU2*YU);

hsnds.oldStableQ = Q1S;
hsnds.oldUnstableQ = Q1U;

hsnds.YS = zeros(size(hsnds.YS));
hsnds.YU = zeros(size(hsnds.YU));

% Update saddle-node borders
[xtmp,x0,p,T,eps0,eps1,YS,YU] = rearr(x);
jac = HSN_odejac(x0,num2cell(p));
Bord = [   jac       hsnds.wvector;...
       hsnds.vvector'      0      ];
bunit = [zeros(hsnds.nphase,1);1];
vext = Bord \ bunit;
wext = Bord' \ bunit;
%ERROR OR WARNING
hsnds.vvector = vext(1:hsnds.nphase)/norm(vext(1:hsnds.nphase));
hsnds.wvector = wext(1:hsnds.nphase)/norm(wext(1:hsnds.nphase));

res = 1;

%----------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ---------------------------------------------------------------
 
function [x,x0,p,T,eps0,eps1,YS,YU] = rearr(x1)
% Rearranges x1 into all of its components
global hsnds

x = x1(hsnds.coords);
x0 = x1(hsnds.ncoords+1:hsnds.ncoords+hsnds.nphase);

p = hsnds.P0;
% p(hsnds.ActiveParams) = x1(hsnds.ncoords+hsnds.nphase+1:hsnds.ncoords+hsnds.nphase+2);
% idx = hsnds.ncoords+hsnds.nphase+3;
p(hsnds.ActiveParams) = x1(hsnds.PeriodIdx+1:hsnds.PeriodIdx+2);
idx = hsnds.PeriodIdx+3;

if hsnds.extravec(1)
    T = x1(idx);
    idx = idx+1;
else
    T = hsnds.T;
end
if hsnds.extravec(2)
    eps0 = x1(idx);
    idx = idx+1;
else
    eps0 = hsnds.eps0;
end
if hsnds.extravec(3)
    eps1 = x1(idx);
    idx = idx+1;
else
    eps1 = hsnds.eps1;
end
    if hsnds.npos
        if ~hsnds.nneg
            YU = reshape(x1(end-(hsnds.nneg+1)*hsnds.npos+1:end),hsnds.nneg+1,hsnds.npos);
        else
            YU = reshape(x1(end-(hsnds.nneg+1)*hsnds.npos-(hsnds.npos+1)*hsnds.nneg+1:end-(hsnds.npos+1)*hsnds.nneg),hsnds.nneg+1,hsnds.npos);
        end
        idx = idx + hsnds.npos*hsnds.nneg;
    else
        YU = [];
    end
    if hsnds.nneg
        YS = reshape(x1(end-(hsnds.npos+1)*hsnds.nneg+1:end),hsnds.npos+1,hsnds.nneg);
    else
        YS = [];
    end
    
% x0
% p
% T
% eps0
% eps1
% YS
% YU
% pause
    
% -------------------------------------------------------------

% ---------------------------------------------------------------

function WorkspaceInit(x,v)
global cds hsnds
hsnds.cols_p1 = 1:(hsnds.ncol+1);
hsnds.cols_p1_coords = 1:(hsnds.ncol+1)*hsnds.nphase;
hsnds.ncol_coord = hsnds.ncol*hsnds.nphase;
hsnds.col_coords = 1:hsnds.ncol*hsnds.nphase;
hsnds.coords = 1:hsnds.ncoords;
hsnds.pars = hsnds.ncoords+(1:2);
hsnds.tsts = 1:hsnds.ntst;
hsnds.cols = 1:hsnds.ncol;
hsnds.phases = 1:hsnds.nphase;
hsnds.ntstcol = hsnds.ntst*hsnds.ncol;

hsnds.idxmat = reshape(fix((1:((hsnds.ncol+1)*hsnds.ntst))/(1+1/hsnds.ncol))+1,hsnds.ncol+1,hsnds.ntst);
hsnds.dt = hsnds.msh(hsnds.tsts+1)-hsnds.msh(hsnds.tsts);

hsnds.wp = kron(hsnds.wpvec',eye(hsnds.nphase));
hsnds.pwwt = kron(hsnds.wt',eye(hsnds.nphase));
hsnds.pwi = hsnds.wi(ones(1,hsnds.nphase),:);

hsnds.wi = nc_weight(hsnds.ncol)';

[hsnds.bialt_M1,hsnds.bialt_M2,hsnds.bialt_M3,hsnds.bialt_M4]=bialtaa(hsnds.nphase);

% ------------------------------------------------------

function [x,v,s] = WorkspaceDone(x,v,s)

%------------------------------------------------------------

function K = fastkron(c,p,A,B)
t = p:((c+2)*p-1);
K = A(ones(1,p),fix(t/p)).*B(:,rem(t,p)+1);
