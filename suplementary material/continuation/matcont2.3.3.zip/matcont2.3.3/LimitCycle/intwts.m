function wts = intwts(z,x,len)
x = z-x;
xmat = x(reshape(rem((len*len-1:-1:len),len)+1,len-1,len));
wts = prod(xmat,1)./prod(xmat-x(ones(1,len-1),:),1);