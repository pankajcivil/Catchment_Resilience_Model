function [x,v] = init_NCH_Hom(odefile, x, v, s, p, ap, ntst, ncol,extravec,T,eps0,eps1)

global homds hsnds cds

if isempty(homds)
    goodds = hsnds;
elseif isempty(hsnds)
    goodds = homds;
elseif norm(hsnds.P0 - p(ap)) < norm(homds.P0 - p(ap))
    goodds = hsnds;
else
    goodds = homds;
end    

if goodds == homds
    [x,v] = init_Hom_HSN(odefile, x, v, s, p, ap, ntst, ncol,extravec,T,eps0,eps1)
    return
else
    [x,v] = init_HSN_HSN(odefile, x, v, s, p, ap, ntst, ncol,extravec,T,eps0,eps1)
    return
end
