function out = hopftest
    out{1} = [];
    out{2} = @hopftestvf;
    out{3} = [];
    out{4} = [];
    out{5} = [];
    out{6} = [];
    out{7} = [];
    out{8} = [];
    out{9} = [];


%
% Vector field for hopftest
%
function dwdt = hopftestvf(t,w,mu,omega)
    x     = w(1);
    y     = w(2);
    dwdt = [    mu*x + omega*y + (x^2+y^2)*x; ...
            -omega*x +    mu*y + (x^2+y^2)*y ];
