function result = first_lyapunovEP(x)
% a = a_lp(x)
% intermediate file for equilibrium environment before normal form computation
%
global eds cds
[x1,p]=rearr(x);p1=n2c(p);
nphase=size(x1,1);
jac=cjac(eds.func,eds.Jacobian,x1,p1);
% calculate eigenvalues
V=eig(jac);
[Y,i]=min(abs(V));
RED=jac-V(i)*eye(nphase);
% compute eigenvectors
borders.v=null(RED);
borders.w=null(RED');
Bord=[jac borders.w;borders.v' 0];
bunit=[zeros(nphase,1);1];
vext=Bord\bunit;
vext=vext(1:nphase);
wext=Bord'\bunit;
wext=wext(1:nphase);
% normalize eigenvectors
vext = vext/norm(vext);
wext = wext/(wext'*vext);
% call to normal form computation file for limit point
result = nf_lp(eds.func,eds.Jacobian,eds.Hessians,x1,p1,vext,wext,nphase);

% ---------------------------------------------------------------
function [x,p] = rearr(x0)
% [x,p] = rearr(x0)
% Rearranges x0 into coordinates (x) and parameters (p)
global eds
p = eds.P0;
p(eds.ActiveParams) = x0(end);
x = x0(1:end-1);
