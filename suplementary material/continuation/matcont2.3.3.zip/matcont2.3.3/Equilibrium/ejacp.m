function j=ejacp(x,p)
global eds cds
if cds.options.SymDerivativeP >= 1
  j = feval(eds.JacobianP, 0, x, p{:});
  j = j(:,eds.ActiveParams);
else
  for i=eds.ActiveParams
    p1 = p; p1{i} = p1{i}-cds.options.Increment;
    p2 = p; p2{i} = p2{i}+cds.options.Increment;
    j(:,i) = feval(eds.func, 0, x, p2{:})-feval(eds.func, 0, x, p1{:});
  end
  j = j/(2*cds.options.Increment);
  j=j(:,eds.ActiveParams);
end
