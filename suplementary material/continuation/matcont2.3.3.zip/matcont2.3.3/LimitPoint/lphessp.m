function h=lphessp(x,p)
global lpds cds

if cds.options.SymDerivativeP >= 2
  h = feval(lpds.HessiansP, 0, x, p{:});
  h = h(:,:,lpds.ActiveParams);
else
  for i=lpds.ActiveParams
    p1 = p; p1{i} = p1{i}-cds.options.Increment;
    p2 = p; p2{i} = p2{i}+cds.options.Increment;
    h(:,:,i) = lpjac(x,p2)-lpjac(x,p1);
  end
  h = h(:,:,lpds.ActiveParams)/(2*cds.options.Increment);
end
