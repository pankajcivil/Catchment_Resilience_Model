function j=hjacp(x,p)
global hds cds
if cds.options.SymDerivativeP >= 1
  j = feval(hds.JacobianP, 0, x, p{:});
  j = j(:,hds.ActiveParams);
else
  for i=hds.ActiveParams
    p1 = p; p1{i} = p1{i}-cds.options.Increment;
    p2 = p; p2{i} = p2{i}+cds.options.Increment;
    j(:,i) = feval(hds.func, 0, x, p2{:})-feval(hds.func, 0, x, p1{:});
  end
  j = j(:,hds.ActiveParams)/(2*cds.options.Increment);
end
