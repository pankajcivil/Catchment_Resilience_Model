function H = conttens3(x)
% Compute numerically hessian matrices of F(x)
%
% hess is a multidimensional matrix: hess(i,j,k) = d^2 F_i / dx_j dx_k

global cds 
ndim      = cds.ndim;
Increment = cds.options.Increment;

if nargin ~= 1 
  error('conthess needs a point');
end
if cds.options.WorkSpace
    odeopt   = feval(cds.curve,'initDer');
    symtens3  = strcmp(odeget(odeopt, 'Tensor3', 'off'), 'on');
else symtens3=0;end
if symtens3
  H = feval(cds.curve, 'tensor3', x);
else
    for i=1:size(x,1)
        x1 = x; x1(i) = x1(i)-cds.options.Increment;
        x2 = x; x2(i) = x2(i)+cds.options.Increment;
        H(:,:,:,i) = conthess(x2)-conthess(x1);
    end
    H = H/(2*cds.options.Increment);
end

%SD:calculates hessians
