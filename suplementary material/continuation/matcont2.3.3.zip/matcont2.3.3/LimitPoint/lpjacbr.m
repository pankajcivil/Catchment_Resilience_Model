function j = lpjacbr(x,p)
global lpds cds

if cds.options.SymDerivativeP >= 1
  j = feval(lpds.JacobianP, 0, x, p{:});
  j = j(:,lpds.BranchParams);
else
  for i=lpds.BranchParams
    p1 = p; p1{i} = p1{i}-cds.options.Increment;
    p2 = p; p2{i} = p2{i}+cds.options.Increment;
    j(:,i) = feval(lpds.func, 0, x, p2{:})-feval(lpds.func, 0, x, p1{:});
  end
  j = j(:,lpds.BranchParams)/(2*cds.options.Increment);

end
