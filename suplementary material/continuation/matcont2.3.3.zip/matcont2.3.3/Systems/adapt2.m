function out = adapt2
out{1} = @init;
out{2} = @fun_eval;
out{3} = [];
out{4} = [];
out{5} = [];
out{6} = [];
out{7} = [];
out{8} = [];
out{9} = [];

% --------------------------------------------------------------------------
function dydt = fun_eval(t,kmrgd,alpha,beta)
dydt=[kmrgd(2);
kmrgd(3);
-alpha*kmrgd(3)-beta*kmrgd(2)-kmrgd(1)+kmrgd(1)^2;];

% --------------------------------------------------------------------------
function [tspan,y0,options] = init
handles = feval(adapt2);
y0=[0,0,0];
options = odeset('Jacobian',[],'JacobianP',[],'Hessians',[],'HessiansP',[]);
tspan = [0 10];

% --------------------------------------------------------------------------
function jac = jacobian(t,kmrgd,alpha,beta)
% --------------------------------------------------------------------------
function jacp = jacobianp(t,kmrgd,alpha,beta)
% --------------------------------------------------------------------------
function hess = hessians(t,kmrgd,alpha,beta)
% --------------------------------------------------------------------------
function hessp = hessiansp(t,kmrgd,alpha,beta)
%---------------------------------------------------------------------------
function tens3  = der3(t,kmrgd,alpha,beta)
%---------------------------------------------------------------------------
function tens4  = der4(t,kmrgd,alpha,beta)
%---------------------------------------------------------------------------
function tens5  = der5(t,kmrgd,alpha,beta)
