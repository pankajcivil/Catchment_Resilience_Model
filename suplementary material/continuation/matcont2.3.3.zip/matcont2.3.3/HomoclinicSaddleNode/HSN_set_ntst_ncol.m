function HSN_set_ntst_ncol(ntst,ncol,nwmesh)
%
% This function sets the number of mesh and collocation points
% as well as a new mesh distribution. All things that depend on
% the number of mesh and/or collocation points are updated.
%
global cds hsnds
hsnds.ntst = ntst;
hsnds.ncol = ncol;

hsnds.tsts = 1:ntst;
hsnds.cols = 1:ncol;
hsnds.tps = hsnds.ntst*hsnds.ncol+1; % number of points on curve

hsnds.ncoords = hsnds.tps*hsnds.nphase;
hsnds.coords = 1:hsnds.ncoords;
hsnds.PeriodIdx = hsnds.ncoords+hsnds.nphase;
hsnds.idxmat = reshape(fix((1:((hsnds.ncol+1)*hsnds.ntst))/(1+1/hsnds.ncol))+1,hsnds.ncol+1,hsnds.ntst);
cds.ndim = hsnds.ncoords+2;
cds.pJacX = [];

hsnds.msh = nwmesh;
hsnds.finemsh = [0 reshape(repmat(hsnds.msh(1:hsnds.ntst),hsnds.ncol,1),1,hsnds.ntst*hsnds.ncol)+kron(hsnds.msh(2:(hsnds.ntst+1))-hsnds.msh(1:hsnds.ntst),((1/hsnds.ncol):(1/hsnds.ncol):1))];
hsnds.dt = hsnds.msh(hsnds.tsts+1)-hsnds.msh(hsnds.tsts);

hsnds.upold = [];
hsnds.upoldp = [];
HSN_calc_weights;
