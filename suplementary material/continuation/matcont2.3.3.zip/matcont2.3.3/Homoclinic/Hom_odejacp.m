function j=Hom_odejacp(x,p)
global homds cds

if cds.options.SymDerivativeP >= 1
  j = feval(homds.JacobianP,0, x,p{:});
else
  for i=homds.ActiveParams
    p1 = p; p1{i} = p1{i}-cds.options.Increment;
    p2 = p; p2{i} = p2{i}+cds.options.Increment;
    j(:,i) = feval(homds.func, 0, x, p2{:})-feval(homds.func, 0, x, p1{:});
  end
  j = j/(2*cds.options.Increment);
end
