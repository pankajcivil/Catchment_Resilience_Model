function j=bpjac(x,p)
global bpds cds

if (cds.options.SymDerivative >=1)
  j = feval(bpds.Jacobian, 0, x, p{:});
else
  for i=1:(cds.ndim-3)
    x1 = x; x1(i) = x1(i)-cds.options.Increment;
    x2 = x; x2(i) = x2(i)+cds.options.Increment;
    j(:,i) = feval(bpds.func, 0, x2, p{:})-feval(bpds.func, 0, x1, p{:});
  end
  j = j/(2*cds.options.Increment);
end
