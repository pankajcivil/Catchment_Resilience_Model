function [x,v] = init_LPC_LC(odefile, x, v, s, ap, ntst, ncol)
%
% [x0,v0] = init_LPC_LC(odefile, x, v, s, ap, ntst, ncol)
%
% Initializes a limit cycle continuation from a cycle calculated
% in a previous run.
%
[x,v] = init_LC_LC(odefile, x, v, s, ap, ntst, ncol)