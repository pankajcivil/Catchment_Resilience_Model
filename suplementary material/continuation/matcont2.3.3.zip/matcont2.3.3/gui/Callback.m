function varargout = Callback(varargin)
global gds path_sys;
h = gcbo;
tag = get(h,'Tag');
st  = str2num(strtok(tag,'edit'));
dim = gds.dim;
ndim = size(gds.parameters,1);
if (st==0)
    value = str2num(get(h,'String'));
    gds.time{1,2} = value;
    gds.integrator.tspan(2) = gds.integrator.tspan(2)-gds.integrator.tspan(1)+gds.time{1,2};
    gds.integrator.tspan(1) = gds.time{1,2};
    file = fullfile(path_sys,gds.system);save(file,'gds');    
    return
end
if (st <= dim) % case coordinates
     value = str2num(get(h,'String'));
     gds.coordinates{st,2} = value;
elseif ((st <= dim+ndim)&(st > dim)) %case parameters
    i = st-gds.dim;
    var = gds.parameters{i,1};
    value = str2num(get(h,'String'));
    gds.parameters{i,2}=value;
else
    gds.period = str2num(get(h,'String'));
end
file = fullfile(path_sys,gds.system);
save(file,'gds');  

