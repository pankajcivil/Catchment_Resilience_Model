function j=odejac(x,p)
global lds cds
if cds.options.SymDerivative >= 1
  j = feval(lds.Jacobian, 0, x,p{:});
else
  for i=lds.phases
    x1 = x; x1(i) = x1(i)-cds.options.Increment;
    x2 = x; x2(i) = x2(i)+cds.options.Increment;
    j(:,i) = feval(lds.func, 0, x2, p{:})-feval(lds.func, 0, x1, p{:});
  end
  j = j/(2*cds.options.Increment);
end
