function j=HSN_odejacp(x,p)
global hsnds cds

if cds.options.SymDerivativeP >= 1
  j = feval(hsnds.JacobianP,0, x,p{:});
else
  for i=hsnds.ActiveParams
    p1 = p; p1{i} = p1{i}-cds.options.Increment;
    p2 = p; p2{i} = p2{i}+cds.options.Increment;
    j(:,i) = feval(hsnds.func, 0, x, p2{:})-feval(hsnds.func, 0, x, p1{:});
  end
  j = j/(2*cds.options.Increment);
end
