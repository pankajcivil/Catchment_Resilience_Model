function f = BVP_HSN(x,x0,p,T,eps0,eps1,YS,YU)
global hsnds 

% extract ups
ups = reshape(x,hsnds.nphase,hsnds.tps);
p = num2cell(p);

% Cycle-component
% ---------------
% Here the cycle is approximated in each mesh interval as a polynomial
% of degree nCol, using the Lagrange polynomials. We approximate using the
% collocation points in the subfunction below, and here we compute the
% values of the polynomials at the mesh points.
range1 = hsnds.cols_p1;
range2 = hsnds.phases;
f = [];
for j=hsnds.tsts
    % value of polynomial on each collocation point
    xval = ups(:,range1)*hsnds.wt;  
    % derivative of polynomial on each collocation point
    derval  = ups(:,range1)*hsnds.wpvec/hsnds.dt(j);
    % evaluate function value on each collocation point
    for c=hsnds.cols
        f(range2,1) = derval(:,c) - 2*T * feval(hsnds.func, 0, xval(:,c), p{:});        
        % Shift for storage
        range2 = range2+hsnds.nphase;
    end
    range1 = range1+hsnds.ncol;
end

% Component 2
% -----------
% equilibrium condition
f(end+1:end+hsnds.nphase,1) = feval(hsnds.func, 0, x0, p{:}); 
    
% Component 2bis
% --------------
% limit point (saddle-node) condition
jac = HSN_odejac(x0,p);
Bord = [   jac       hsnds.wvector;...
       hsnds.vvector'      0      ];
bunit = [zeros(hsnds.nphase,1);1];
vext = Bord \ bunit;
f(end+1,1) = vext(end); 
    
% Component 3
% -----------
% Integral constraint (phase condition)
if isempty(hsnds.upold)
    hsnds.upold = ups;
end
dotprod = dot(ups-hsnds.upold, hsnds.upoldp);
dotprodmatrix = dotprod(hsnds.idxmat);
f(end+1,1) = sum(hsnds.dt .* (hsnds.wi * dotprodmatrix));

% Component 4
% -----------
% Ricatti equations
tmp = HSN_ricattiEval(x0,p,YU,YS);
f(end+1:end+length(tmp)) = tmp;

% Component 5
% -----------
% Last and first vectors along stable and unstable eigenspaces
Q0S = hsnds.oldStableQ;
Q0U = hsnds.oldUnstableQ;
opts.disp = 0;
% [V,D] = eigs(jac,1,'SM',opts);
[V,D] = eig(jac);
[Y,i] = min(abs(diag(D)));
V = V(:,i);
D = D(i,i);

if hsnds.nneg
    if hsnds.npos
        Q1U = Q0U * [eye(size(YU,1)); YU];
    else
        Q1U = [];
    end
    Qtot = [Q1U V];
    [Qn,Rn] = qr(Qtot);
    for i=1:hsnds.nneg
        f(end+1,1) = (ups(:,1) - x0)' * Qn(:,end-i+1);
    end
end
if hsnds.npos
    if hsnds.nneg
        Q1S = Q0S * [eye(size(YS,1)); YS];
    else
        Q1S = [];
    end
    Qtot = [Q1S V];
    [Qn,Rn] = qr(Qtot);
    for i=1:hsnds.npos
        f(end+1,1) = (ups(:,end) - x0)' * Qn(:,end-i+1);
    end
end

% Component 6
% -----------
% Distances from endpoints to equilibrium equal to epsilons
f(end+1,1) = norm(ups(:,1) - x0) - eps0;
f(end+1,1) = norm(ups(:,end) - x0) - eps1;

% norm(f)
% save f f
% norm(tops)
% pause