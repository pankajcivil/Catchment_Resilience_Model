function h=Hom_odehess(x,p)
global homds cds

if cds.options.SymDerivative >= 2
  h = feval(homds.Hessians, 0, x, p{:});
else
  for i=homds.phases
    x1 = x; x1(i) = x1(i)-cds.options.Increment;
    x2 = x; x2(i) = x2(i)+cds.options.Increment;
    h(:,:,i) = Hom_odejac(x2,p)-Hom_odejac(x1,p);
  end
  h = h/(2*cds.options.Increment);
end
