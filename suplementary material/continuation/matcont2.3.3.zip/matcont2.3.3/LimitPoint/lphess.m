function h=lphess(x,p)
global lpds cds

if (cds.options.SymDerivative >=2)
  h = feval(lpds.Hessians, 0, x, p{:});
else
  for i=1:lpds.nphase
    x1 = x; x1(i) = x1(i)-cds.options.Increment;
    x2 = x; x2(i) = x2(i)+cds.options.Increment;
    h(:,:,i) = lpjac(x2,p)-lpjac(x1,p);
  end
  h = h/(2*cds.options.Increment);
end
