function h=bphesspp(x,p)
global bpds cds
k=0;
for i=bpds.ActiveParams
    k=k+1;  
    p1 = p; p1{i} = p1{i}-cds.options.Increment;
    p2 = p; p2{i} = p2{i}+cds.options.Increment;
    h(:,:,k) = bpjacbr(x,p2)-bpjacbr(x,p1);
end
h = h(:,:,1:k)/(2*cds.options.Increment);

