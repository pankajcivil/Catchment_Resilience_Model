function out = MyML
out{1} = @init;
out{2} = @fun_eval;
out{3} = [];
out{4} = [];
out{5} = [];
out{6} = [];
out{7} = [];
out{8} = [];
out{9} = [];

% --------------------------------------------------------------------------
function dydt = fun_eval(t,kmrgd,Inp,V3)
Minf=(1+tanh((kmrgd(1)+1.2)/18))/2;
Ninf=(1+tanh((kmrgd(1)-V3)/17.4))/2;
tau=1/15*cosh((kmrgd(1)-V3)/34.8);
dydt=[1/5*(Inp-2*(kmrgd(1)+60)-4*Minf*(kmrgd(1)-120)-8*kmrgd(2)*(kmrgd(1)+80));
tau*(Ninf-kmrgd(2));];

% --------------------------------------------------------------------------
function [tspan,y0,options] = init
handles = feval(MyML);
y0=[0,0];
options = odeset('Jacobian',[],'JacobianP',[],'Hessians',[],'HessiansP',[]);
tspan = [0 10];

% --------------------------------------------------------------------------
function jac = jacobian(t,kmrgd,Inp,V3)
% --------------------------------------------------------------------------
function jacp = jacobianp(t,kmrgd,Inp,V3)
% --------------------------------------------------------------------------
function hess = hessians(t,kmrgd,Inp,V3)
% --------------------------------------------------------------------------
function hessp = hessiansp(t,kmrgd,Inp,V3)
%---------------------------------------------------------------------------
function tens3  = der3(t,kmrgd,Inp,V3)
%---------------------------------------------------------------------------
function tens4  = der4(t,kmrgd,Inp,V3)
%---------------------------------------------------------------------------
function tens5  = der5(t,kmrgd,Inp,V3)
