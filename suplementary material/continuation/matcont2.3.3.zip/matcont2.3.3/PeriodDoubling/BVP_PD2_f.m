% -------------------------------------------------------------
% functions defining the BVP for limitcycles
% -------------------------------------------------------------

function f = BVP_PD2_f(odefile,t,xp,yp,p,T)
f = t-T*odejac(xp,p)*yp;

