function j=bpjacp(x,p)
global bpds cds

if cds.options.SymDerivativeP >= 1
  j = feval(bpds.JacobianP, 0, x, p{:});
  j = j(:,bpds.ActiveParams);
else
    k=0;
    for  i=bpds.ActiveParams
        k = k+1;
        p1 = p; p1{i} = p1{i}-cds.options.Increment;
        p2 = p; p2{i} = p2{i}+cds.options.Increment;
        j(:,k) = feval(bpds.func, 0, x, p2{:})-feval(bpds.func, 0, x, p1{:});
    end
    j = j/(2*cds.options.Increment);
end