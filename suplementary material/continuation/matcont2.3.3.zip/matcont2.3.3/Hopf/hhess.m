function h=hhess(x,p)
global hds cds
if cds.options.SymDerivative >= 2
  h = feval(hds.Hessians, 0, x, p{:});
else
    for i=1:hds.nphase
        x1 = x; x1(i) = x1(i)-cds.options.Increment;
        x2 = x; x2(i) = x2(i)+cds.options.Increment;
        h(:,:,i) = hjac(x2,p)-hjac(x1,p);
    end
    h = h/(2*cds.options.Increment);
end
