function [x,v] = init_BT_Hom(odefile, x, p, ap, ntst, ncol, extravec, T, eps0, eps1, eps)
global homds lpds hds cds

% check input
n_par = size(ap,2);
nextra = length(find(extravec));
if (n_par + nextra) ~= 4
    error('4 active and free homoclinic parameters are needed');
end

if ~isempty(hds)
    tempds = hds;
else
    tempds = lpds;
end

if isempty(cds) || ~isfield(cds,'options')
    cds.options = contset();
end
cds.curve = @homoclinic;
cds.symhess = 0;
cds.symjac  = 1; 
curvehandles = feval(cds.curve);
cds.curve_func = curvehandles{1};
cds.curve_jacobian = curvehandles{4};
cds.curve_hessians = curvehandles{5};

% Symbolic derivatives defined?
eds.odefile = odefile;
func_handles = feval(eds.odefile);
eds.func = func_handles{2};
eds.Jacobian  = func_handles{3};
eds.JacobianP = func_handles{4};
eds.Hessians  = func_handles{5};
eds.HessiansP = func_handles{6};
symord = 0; 
symjac = ~isempty(eds.Jacobian);
symhes = ~isempty(eds.Hessians);
if symjac,   symord = 1; end
if symhes,   symord = 2; end
cds.options = contset(cds.options, 'SymDerivative', symord);
symordp = 0;
symjacp = ~isempty(eds.JacobianP); 
symhes = ~isempty(eds.HessiansP);
if symjacp, symordp = 1; end
if symhes,  symordp = 2; end
cds.options = contset(cds.options, 'SymDerivativeP', symordp);


homds = [];
% initialize homds
eps0=1e-2;
eps1=1e-2;
init_homds(odefile,x,p,ap,ntst,ncol,extravec,T,eps0,eps1,tempds);

cds.pJac = [];
cds.pJacX = [];
xp = [x;p(ap)];
cds.ndim = length(xp);

homds.x0 = x(1:homds.nphase);
    
pcell = num2cell(p);
% Compute A, A1
A = Hom_odejac(homds.x0,pcell);
A1 = Hom_odejacp(homds.x0,pcell);
if size(A1,2) > length(ap)
    A1 = A1(:,ap);
end
    
% Compute B, B1 and B2
B = Hom_odehess(homds.x0,pcell);
B1 = Hom_odehessp(homds.x0,pcell);
if size(B1,3) > length(ap)
    B1 = B1(:,:,ap);
end

for i=homds.ActiveParams
    p1 = pcell; p1{i} = p1{i}-cds.options.Increment;
    p2 = pcell; p2{i} = p2{i}+cds.options.Increment;
    Hjp2 = Hom_odejacp(homds.x0,p2);
    Hjp1 = Hom_odejacp(homds.x0,p1);
    if size(Hjp2,2) > length(ap)
        Hjp1 = Hjp1(:,ap);
        Hjp2 = Hjp2(:,ap);
    end
    tmph(:,:,i) = Hjp2 - Hjp1;
end
tmph = tmph/(2*cds.options.Increment);
B2 = tmph;
if size(B2,3) > length(ap)
    B2 = B2(:,:,ap);
end
    
% % Compute all vectors needed
% [V,D] = eig(A);
% [val,ind] = min(abs(diag(D)));
% d = D(ind,ind);
% q01 = V(:,ind);
% [W,D] = eig(A');
% [val,ind] = min(abs(diag(D)));
% val = D(ind,ind);    
% p11 = W(:,ind);
% if val == -d
%     p11 = -p11;
% end
% % [q01,d] = eigs(A,1,'SM');
% % [p11,d] = eigs(A',1,'SM');
% q01 = real(q01);
% p11 = real(p11);
%     
% bigA = [A p11; q01' 0];
% q11 = bigA \ [q01;0];
% q11 = q11(1:end-1);
% p01 = (bigA') \ [p11;0];
% p01 = p01(1:end-1);
%     
% % Compute normalisation coefficients
% H1 = q01' * p01;
% H2 = q11' * p01;
% alpha = 1 / norm(q01);
% beta = 1 / (alpha * H1);
% gamma = alpha;
% delta = -H2 / (2 * beta * H1^2);
% epsilon = beta;
% phi = -H2 / (2 * alpha * H1^2);
%     
% % Normalize these vectors
% q0 = alpha * q01;
% p1 = beta * p11;
% q1 = gamma * q11 + delta * q01;
% p0 = epsilon * p01 + phi * p11;
    
  [X,D] = eig(A);
  index1 = find(abs(diag(D)) < 1e-3);%If ok, index1 is 1x2 array otherwise
  vext = real(X(:,index1(1)));
  [X,D] = eig(A');
  index1 = find(abs(diag(D)) < 1e-3);
  wext = real(X(:,index1(1)));
  Bord = [ jac wext; vext' 0];
  bunit=[zeros(nphase,1);1];
  q0=Bord\bunit; 
  q0=q0(1:nphase);          % A q0 = 0, <vext,q0> = 1
  p1=Bord'\bunit;
  p1=p1(1:nphase);          % A'p1 = 0, <wext,p1> = 1
  Bord = [ jac p1; q0' 0];
  q1 = Bord\[q0; 0];		
  q1 = q1(1:nphase);		% A q1 = q0, <q0,q1> = 0
  p0 = Bord'\[p1; 0];
  p0 = p0(1:nphase);		% A'p0 = p1, <p0,p1> = 0

% normalize so that <p0,q0>=<p1,q1>=1, <p0,q1>=<p1,q0>=0 and <q0,q0>=1, <q0,q1>=0
  mu = sqrt(abs(q0'*q0));
  q0 = (1/mu)*q0;
  q1 = (1/mu)*q1;
  q1 = q1 - (q0'*q1)*q0;
  nu = q0'*p0;
  p1 = (1/nu)*p1;
  p0 = p0 - (p0'*q1)*p1;
  p0 = (1/nu)*p0;
  
% Compute a
a = zeros(1,homds.nphase);
for i=1:homds.nphase
    a(i) = p1' * B(:,:,i) * q0;
end    
a = 1/2 * a * q0;
    
% K1, H01 and K2
gamma = (p1' * A1);
K1 = 1/(gamma(1)^2 + gamma(2)^2) * [gamma(1)  -gamma(2);  gamma(2)   gamma(1)];
tmpH = [q1 zeros(size(q1))] - A1 * K1;
H01 = bigA \ [tmpH; zeros(1,size(tmpH,2))];
H01 = H01(1:end-1,:);
for i=1:homds.nphase
    p1B(:,i) = p1' * B(:,:,i) * H01(:,2);
end
for i=1:length(ap)
    p1B1(:,i) = p1' * B1(:,:,i) * H01(:,2);
    p1B2(:,i) = p1' * B2(:,:,i) * K1(:,2);
end
p1B = p1B * H01(:,2);
p1B1 = p1B1 * K1(:,2);
p1B2 = p1B2 * K1(:,2);
K2 = -(p1B + 2 * p1B1 + p1B2) * K1(:,1);
    
% Actual approximation: alpha 
alpha = -5/7 * eps^2 * K1(:,2) + eps^4/49 * (-6 * K1(:,1) + 12.5 * K2);
p(ap) = p(ap) + alpha; %   tmpfreep = tmpfreep + alpha;
homds.P0 = p;
% Actual approximation: cycle
for i=1:length(homds.finemsh)
    % conversion from [0,1] -> [-T,T]
    t = (2*homds.finemsh(i) - 1) * (homds.T);
        
    ups(:,i) = eps^2 * (-5/7*H01(:,2) + 1/(4*a) * ...
        (2 - 6 * (sech(t * eps/2))^2 + 10/7) * q0) + eps^3 / (8*a) *...
        (12 * (sech(t * eps/2))^2 * tanh(t * eps/2)) * q1;
    ups(:,i) = ups(:,i) + homds.x0;
end
% Actual approximation: equilibrium
homds.x0 = homds.x0 + eps^2 * (-5/7*H01(:,2) + 6/(7*a) * q0);
x0 = homds.x0;
    
Hom_calc_weights;

A = Hom_odejac(x0,num2cell(p));
D = eig(A);
% nneg = dimension of stable subspace
homds.nneg = sum(real(D) < 0);
homds.npos = homds.nphase-homds.nneg;
homds.Ysize = homds.nneg*homds.npos;

homds.eps0 = norm(ups(:,1) - homds.x0);
homds.eps1 = norm(ups(:,end) - homds.x0);

% COMPOSE X0
% ----------

% 1. cycle 
x1 = reshape(ups,size(ups,1)*size(ups,2),1);
v = []; 
[x1,v]=Hom_new_mesh(x1,v,ntst,ncol);

% 2. equilibrium coordinates
x1 = [x1; x0];
% 3. (two) free parameters
x1 = [x1; homds.P0(homds.ActiveParams)];
% 4. extra free parameters
extravec = [homds.T; homds.eps0; homds.eps1];
x1 = [x1; extravec(find(homds.extravec))];
% 5. YS and YU, initialized to 0
for i=1:homds.nneg
    x1 = [x1; zeros(homds.npos,1)];
end
for i=1:homds.npos
    x1 = [x1; zeros(homds.nneg,1)];
end

% ASSIGN SOME VALUES TO HOMOCLINIC FIELDS
% ---------------------------------------

homds.YS = zeros(homds.npos,homds.nneg);
homds.YU = zeros(homds.nneg,homds.npos);

% Third parameter = unstable_flag, 
% 1 if we want the unstable space, 0 if we want the stable one
[QS, eigvlS, dimS] = computeBase(A,0,homds.nneg);
[QU, eigvlU, dimU] = computeBase(A,1,homds.npos);

homds.oldStableQ = QS;
homds.oldUnstableQ = QU;
homds.ups = [];


figure
plot(ups(1,:),ups(2,:))
pause

x = x1;
v=[];

%-----------------------------------------------------------------
function init_homds(odefile,x,p,ap,ntst,ncol,extravec,T,eps0,eps1,tempds)
global homds 
homds.odefile = odefile;
func_handles = feval(homds.odefile);
homds.func = func_handles{2};
homds.Jacobian  = func_handles{3};
homds.JacobianP = func_handles{4};
homds.Hessians  = func_handles{5};
homds.HessiansP = func_handles{6};
homds.Der3=[];
siz = size(func_handles,2);
if siz > 9
    j=1;
    for k=10:siz
        homds.user{j}= func_handles{k};
        j=j+1;
    end
else homds.user=[];end
homds.nphase = tempds.nphase;
homds.ActiveParams = ap;
homds.P0 = p;
Hom_set_ntst_ncol(ntst,ncol,(0:ntst)/ntst);
homds.extravec = extravec;
homds.T = T;
homds.eps0 = eps0;
homds.eps1 = eps1;
homds.cols_p1 = 1:(homds.ncol+1);
homds.cols_p1_coords = 1:(homds.ncol+1)*homds.nphase;
homds.ncol_coord = homds.ncol*homds.nphase;
homds.col_coords = 1:homds.ncol*homds.nphase;
homds.pars = homds.ncoords+(1:3);
homds.phases = 1:homds.nphase;
homds.ntstcol = homds.ntst*homds.ncol;
homds.wp = kron(homds.wpvec',eye(homds.nphase));
homds.pwwt = kron(homds.wt',eye(homds.nphase));
homds.pwi = homds.wi(ones(1,homds.nphase),:);

homds.bialt_M1 = [];
homds.bialt_M2 = [];
homds.bialt_M3 = [];
homds.bialt_M4 = [];
homds.multipliers = nan;
homds.monodromy = [];
homds.multi_r1 = [];
homds.multi_r2 = [];
homds.ups = [];
homds.vps = [];
homds.tsts = 1:homds.ntst;
homds.cols = 1:homds.ncol;

homds.HTPstep = 0;