function HSN_calc_weights()
% calculate weights

global hsnds

hsnds.wi = nc_weight(hsnds.ncol)';
hsnds.wt = [];
hsnds.wpvec = [];
zm = gl_pos(hsnds.ncol)/2 + 0.5;
xm = (0:hsnds.ncol)/hsnds.ncol;

ncp1 = hsnds.ncol+1;
for j=1:ncp1
  xmi = xm(setdiff(1:ncp1,j));
  denom = prod(xm(j)-xmi);
  hsnds.wt(j,:) = prod(repmat(zm',hsnds.ncol,1)-repmat(xmi',1,hsnds.ncol))/denom;
  s = zeros(1,hsnds.ncol);
  for l=setdiff(1:ncp1,j)
    xmil = xm(setdiff(1:ncp1,[j l]));
    rep = repmat(zm',hsnds.ncol-1,1)-repmat(xmil',1,hsnds.ncol);
    if hsnds.ncol > 2
      s = s+prod(rep);
    else
      s = s+rep;
    end
  end
  hsnds.wpvec(j,:) = s/denom;
end
