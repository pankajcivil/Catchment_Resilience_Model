function [x,v]=HSN_new_mesh(x,v,ntst,ncol)
global hsnds

% some values we need
oldncoord = hsnds.ncoords;

% construct ups
ups = reshape(x(hsnds.coords),hsnds.nphase,hsnds.tps);

% calculate new mesh
tmnew = homnewmesh(ups,hsnds.msh,hsnds.ntst,hsnds.ncol,ntst,ncol);

% interpolate ups on new mesh
ups = interp(hsnds.msh,hsnds.ncol,ups,tmnew,ncol);
x = [ups(:);x((oldncoord+1):end)];

% interpolate vps if supplied
if ~isempty(v)
  vps = interp(hsnds.msh,hsnds.ncol,reshape(v(hsnds.coords),hsnds.nphase,hsnds.tps),tmnew,ncol);
  v = [vps(:);v((oldncoord+1):end)];
  v = v/norm(v);
end

% store new mesh
HSN_set_ntst_ncol(ntst,ncol,tmnew);
