% -------------------------------------------------------------
% functions defining the jacobian of the BVP for fold(LPC) bifurcations
% -------------------------------------------------------------

% function
function f = BVP_NS_f(odefile,xp,p,T,tp)
global lds
wploc = lds.wp/lds.dt(tp);
range = lds.phases;
for c=lds.cols
  sysjac(range,:) = fastkron(lds.ncol,lds.nphase,lds.wt(:,c)',odejac(xp(:,c),p));
  range = range + lds.nphase;
end
f = [wploc-T*sysjac    lds.NS_psi0((tp-1)*lds.ncol_coord + lds.col_coords)   lds.NS_psi1((tp-1)*lds.ncol_coord + lds.col_coords)];
