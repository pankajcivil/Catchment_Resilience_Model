function [x,v]=HSN_adapt_mesh(x,v)
%
% re-interpolates a given x and v on a new mesh such that the
% error in x is approximately uniformly spread over the mesh
% points.
%
global hsnds

% construct ups and vps
ups = reshape(x(hsnds.coords),hsnds.nphase,hsnds.tps);
vps = reshape(v(hsnds.coords),hsnds.nphase,hsnds.tps);

% calculate new mesh
tmnew = hsnnewmesh(ups,hsnds.msh,hsnds.ntst,hsnds.ncol,hsnds.ntst,hsnds.ncol);

% interpolate ups and vps on new mesh
ups = interp(hsnds.msh,hsnds.ncol,ups,tmnew,hsnds.ncol);
vps = interp(hsnds.msh,hsnds.ncol,vps,tmnew,hsnds.ncol);

% store new mesh
hsnds.msh = tmnew;
hsnds.finemsh = [0 reshape(repmat(hsnds.msh(hsnds.tsts),hsnds.ncol,1),1,hsnds.ntst*hsnds.ncol)+kron(hsnds.msh((hsnds.tsts+1))-hsnds.msh(hsnds.tsts),((1/hsnds.ncol):(1/hsnds.ncol):1))];

hsnds.dt = hsnds.msh(hsnds.tsts+1)-hsnds.msh(hsnds.tsts);

% set result
x = [ups(:);x(hsnds.ncoords+1:end)];
v = [vps(:);v(hsnds.ncoords+1:end)];
% 
% % store new mesh
% Hom_set_ntst_ncol(hsnds.ntst,hsnds.ncol,tmnew);
