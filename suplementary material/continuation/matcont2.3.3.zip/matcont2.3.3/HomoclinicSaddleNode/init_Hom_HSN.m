function [x,v] = init_Hom_HSN(odefile, x,s, p, ap, ntst, ncol,extravec,T,eps0,eps1)

global hsnds cds homds

% check input
n_par = size(ap,2);
nextra = length(find(extravec));
if (n_par + nextra) ~= 4
    error('4 active and free homoclinic parameters are needed');
end

if isempty(cds) || ~isfield(cds,'options')
    cds.options = contset();
end
cds.curve = @homoclinicsaddlenode;
cds.symhess = 0;
cds.symjac  = 1; 
curvehandles = feval(cds.curve);
cds.curve_func = curvehandles{1};
cds.curve_defaultprocessor = curvehandles{2};
cds.curve_jacobian = curvehandles{4};
cds.curve_hessians = curvehandles{5};
cds.curve_testf = curvehandles{6};
cds.curve_adapt = curvehandles{13};


if size(x,2) > 1
    x = x(:,s.index);
end
hsnds = [];

% initialize hsnds
init_hsnds(odefile,x,p,ap,homds.ntst,homds.ncol,extravec,T,eps0,eps1,s);

func_handles = feval(odefile);
symord = 0; 
symordp = 0;

if     ~isempty(func_handles{9}),   symord = 5; 
elseif ~isempty(func_handles{8}),   symord = 4; 
elseif ~isempty(func_handles{7}),   symord = 3; 
elseif ~isempty(func_handles{5}),   symord = 2; 
elseif ~isempty(func_handles{3}),   symord = 1; 
end
if     ~isempty(func_handles{6}),   symordp = 2; 
elseif ~isempty(func_handles{4}),   symordp = 1; 
end
cds.options = contset(cds.options, 'SymDerivative', symord);
cds.options = contset(cds.options, 'SymDerivativeP', symordp);


hsnds.odefile = odefile;
hsnds.func = func_handles{2};
hsnds.Jacobian  = func_handles{3};
hsnds.JacobianP = func_handles{4};
hsnds.Hessians  = func_handles{5};
hsnds.HessiansP = func_handles{6};
hsnds.Der3 = func_handles{7};
hsnds.Der4 = func_handles{8};
hsnds.Der5 = func_handles{9};

xold = x;

x = x(1:hsnds.nphase*hsnds.tps);

cds.pJac = [];
cds.pJacX = [];
xp = [x;p(ap)];
cds.ndim = length(xp);
     
A = Hom_odejac(hsnds.x0,num2cell(p));
D = eig(A);
% nneg = dimension of stable subspace
[y,i] = min(abs(D));
hsnds.nneg = sum(real(D) < 0);
hsnds.npos = sum(real(D) > 0);
if D(i) < 0
    hsnds.nneg = hsnds.nneg-1;
else
    hsnds.npos = hsnds.npos-1;
end
hsnds.Ysize = (hsnds.nneg+1)*hsnds.npos + hsnds.nneg*(hsnds.npos+1);

% COMPOSE X0
% ----------

% 1. cycle 
x1 = x(1:hsnds.ncoords);

if ~exist('v') || size(v) ~= size(x)
    v = [];
end
[x1,v]=HSN_new_mesh(x1,v,ntst,ncol);

% 2. equilibrium coordinates
x1 = [x1; hsnds.x0];
hsnds.PeriodIdx = length(x1);
% 3. (two) free parameters
x1 = [x1; hsnds.P0(hsnds.ActiveParams)];
% 4. extra free parameters
extravec = [hsnds.T; hsnds.eps0; hsnds.eps1];
x1 = [x1; extravec(find(hsnds.extravec))];
% 5. YS and YU, initialized to 0
for i=1:hsnds.nneg
    x1 = [x1; zeros(hsnds.npos+1,1)];
end
for i=1:hsnds.npos
    x1 = [x1; zeros(hsnds.nneg+1,1)];
end

x = x1;

% ASSIGN SOME VALUES TO HOMOCLINIC FIELDS
% ---------------------------------------

hsnds.YS = zeros(hsnds.npos+1,hsnds.nneg);
hsnds.YU = zeros(hsnds.nneg+1,hsnds.npos);

[Y,i] = min(abs(D));
RED = A - D(i) * eye(hsnds.nphase);
hsnds.vvector = null(RED);
hsnds.wvector = null(RED');

% Third parameter = unstable_flag, 
% 1 if we want the unstable space, 0 if we want the stable one
[QS, eigvlS, dimS] = computeBase(A,0,hsnds.nneg);
[QU, eigvlU, dimU] = computeBase(A,1,hsnds.npos);

hsnds.oldStableQ = QS;
hsnds.oldUnstableQ = QU;
hsnds.ups = [];
hsnds.upold = [];
hsnds.upoldp = [];

x = x1;
v=[];

%-----------------------------------------------------------------
function init_hsnds(odefile,x,p,ap,ntst,ncol,extravec,T,eps0,eps1,s)
global hsnds homds
hsnds.odefile = odefile;
func_handles = feval(hsnds.odefile);
hsnds.func = func_handles{2};
hsnds.Jacobian  = func_handles{3};
hsnds.JacobianP = func_handles{4};
hsnds.Hessians  = func_handles{5};
hsnds.HessiansP = func_handles{6};
hsnds.Der3=[];
siz = size(func_handles,2);
if siz > 9
    j=1;
    for k=10:siz
        hsnds.user{j}= func_handles{k};
        j=j+1;
    end
else hsnds.user=[];end
hsnds.nphase = homds.nphase;
% hsnds.x0 = homds.x0;
hsnds.x0 = x(homds.ncoords+1:homds.ncoords+homds.nphase);
hsnds.ActiveParams = ap;
hsnds.P0 = p;
HSN_set_ntst_ncol(ntst,ncol,s.data.timemesh);
% hsnds.dt = homds.dt;
% hsnds.msh = homds.msh;
% hsnds.finemsh = homds.finemsh;
hsnds.extravec = extravec;
hsnds.T = T;
hsnds.eps0 = eps0;
hsnds.eps1 = eps1;
hsnds.cols_p1 = 1:(hsnds.ncol+1);
hsnds.cols_p1_coords = 1:(hsnds.ncol+1)*hsnds.nphase;
hsnds.ncol_coord = hsnds.ncol*hsnds.nphase;
hsnds.col_coords = 1:hsnds.ncol*hsnds.nphase;
hsnds.pars = hsnds.ncoords+(1:3);
hsnds.phases = 1:hsnds.nphase;
hsnds.ntstcol = hsnds.ntst*hsnds.ncol;
hsnds.wp = kron(hsnds.wpvec',eye(hsnds.nphase));
hsnds.pwwt = kron(hsnds.wt',eye(hsnds.nphase));
hsnds.pwi = hsnds.wi(ones(1,hsnds.nphase),:);

hsnds.bialt_M1 = [];
hsnds.bialt_M2 = [];
hsnds.bialt_M3 = [];
hsnds.bialt_M4 = [];
hsnds.multipliers = nan;
hsnds.monodromy = [];
hsnds.multi_r1 = [];
hsnds.multi_r2 = [];
hsnds.ups = [];
hsnds.vps = [];
hsnds.tsts = 1:hsnds.ntst;
hsnds.cols = 1:hsnds.ncol;

hsnds.HTPstep = 0;

% Border needed for the constraint that the equilibrium is a saddle-node
hsnds.wvector = [];
hsnds.vvector = [];
