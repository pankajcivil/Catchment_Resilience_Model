% -------------------------------------------------------------
% functions defining the jacobian of the BVP for fold (LPC) bifurcations
% -------------------------------------------------------------

% integral contraint
function ic = BVP_LPC_ic()
global lds
ic = zeros(1,lds.ncoords);
range2 = lds.cols_p1_coords;
for j=lds.tsts
  d=reshape(lds.LPC_phi(range2),lds.nphase,lds.ncol+1);
  p = lds.dt(j)*(d(:,lds.cols_p1).*lds.pwi);
  p=reshape(p,1,lds.nphase*(lds.ncol+1));
  ic(range2) = ic(range2)+p(lds.cols_p1_coords);
  range2 = range2 + lds.ncol_coord;
end
