function v=Hessvect(a,b,hess,phase)
for h=1:phase
    B=reshape(hess(h,:,:),phase,phase);
    v(h,1)=a.'*B*b;
end
