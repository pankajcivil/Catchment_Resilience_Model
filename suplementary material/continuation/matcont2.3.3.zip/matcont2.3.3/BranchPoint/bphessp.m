function h=bphessp(x,p)
global bpds cds

if cds.options.SymDerivativeP >= 2
  h = feval(bpds.HessiansP, 0, x, p{:});
  h = h(:,:,bpds.ActiveParams);
else
  k=0;  
  for i=bpds.ActiveParams
    k=k+1;
    p1 = p; p1{i} = p1{i}-cds.options.Increment;
    p2 = p; p2{i} = p2{i}+cds.options.Increment;
    h(:,:,k) = bpjac(x,p2)-bpjac(x,p1);
  end
  h = h(:,:,1:k)/(2*cds.options.Increment);
end
