% Ricatti evaluation file
% =======================

function result = HSN_ricattiEval(x0,p,YU,YS)

global hsnds

Q0S = hsnds.oldStableQ;
Q0U = hsnds.oldUnstableQ;
A = HSN_odejac(x0,p);
result = [];

if ~isempty(YU)
    % Riccati blocks from unstable eigenspace
    [U11, U12, UE21, U22] = ricattiCoeff(Q0U,A,hsnds.npos);
    tmp = (U22*YU - YU*U11 + UE21 - YU*U12*YU)';
    for i=1:hsnds.nneg+1
        result(end+1:end+hsnds.npos,1) = tmp(:,i);
    end
end

if ~isempty(YS)
    % Riccati blocks from stable eigenspace
    [S11, S12, SE21, S22] = ricattiCoeff(Q0S,A,hsnds.nneg);
    tmp = (S22*YS - YS*S11 + SE21 - YS*S12*YS)';
    for i=1:hsnds.npos+1
        result(end+1:end+hsnds.nneg,1) = tmp(:,i);
    end
end

