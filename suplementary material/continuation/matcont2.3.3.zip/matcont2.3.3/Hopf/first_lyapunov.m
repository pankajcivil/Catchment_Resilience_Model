function fl=first_lyapunov(odefile,jacobian,hessians,tensor,x0,p1,k,vext,wext,nphase)
%
%calculates the first lyapunov coefficient
% 
global eds cds
%compute jacobian and eigenvectors.
  jac=cjac(odefile,jacobian,x0,p1);
  omega=sqrt(k);
  alpha=vext(1:nphase,1)'*jac*vext(1:nphase,2)-1i*omega*vext(1:nphase,1)'*vext(1:nphase,2);
  beta=-vext(1:nphase,1)'*jac*vext(1:nphase,1)+1i*omega*vext(1:nphase,1)'*vext(1:nphase,1);
  q=alpha*vext(1:nphase,1)+beta*vext(1:nphase,2);
  alpha=wext(1:nphase,1)'*jac'*wext(1:nphase,2)+1i*omega*wext(1:nphase,1)'*wext(1:nphase,2);
  beta=-wext(1:nphase,1)'*jac'*wext(1:nphase,1)-1i*omega*wext(1:nphase,1)'*wext(1:nphase,1);
  p=alpha*wext(1:nphase,1)+beta*wext(1:nphase,2);
  q=q/norm(q);
  p=p/(q'*p);
  
% if cds.options.SymDerivative >= 3
%   hess=chess(odefile,jacobian,hessians,x0,p1);
%   tens=ctens3(odefile,jacobian,hessians,tensor,x0,p1);
%   t1=zeros(nphase,1);
%   for i=1:nphase
%     for j=1:nphase
%         B=reshape(tens(i,j,:,:),nphase,nphase);
%         t1(i)=t1(i)+q.'*B*q*conj(q(j));		%C(q,q,q_)     
%     end
%   end
%   test=Hessvect(q,conj(q),hess,nphase);		%B(q,_q)
%   test=jac\test;      				%A^(-1)*B(q,_q)   
%   t2=Hessvect(q,test,hess,nphase);   		%B(q,A^(-1)*B(q,_q))    
%   test=Hessvect(q,q,hess,nphase);  		%B(q,q)      
%   test=(2i*omega*eye(nphase)-jac)\test;		%(2iwIn-A)_1*B(q,q)      
%   t3=Hessvect(conj(q),test,hess,nphase);	%B(_q,(2iwIn-A)_1*B(q,q))
%   fl=real(p'*(t1-2*t2+t3))/2.0; 
% else
  hessIncrement =(cds.options.Increment)^(3.0/4.0);
  x1 = x0 + hessIncrement*q;
  x2 = x0 - hessIncrement*q;
  f0 = feval(odefile, 0, x0, p1{:});
  f1 = feval(odefile, 0, x1, p1{:});
  f2 = feval(odefile, 0, x2, p1{:});
  h1 = (f1+f2-2.0*f0)/hessIncrement/hessIncrement;	%B(q,q);
  h1 = (2i*omega*eye(nphase)-jac)\h1;			%(2iwIn-A)_1*B(q,q)  
  x1 = x0 + hessIncrement*(conj(q)+h1);
  x2 = x0 - hessIncrement*(conj(q)+h1);
  x3 = x0 + hessIncrement*(conj(q)-h1);
  x4 = x0 - hessIncrement*(conj(q)-h1);
  f1 = feval(odefile, 0, x1, p1{:});
  f2 = feval(odefile, 0, x2, p1{:});
  f3 = feval(odefile, 0, x3, p1{:});
  f4 = feval(odefile, 0, x4, p1{:});
  h1 = ((f1+f2)-(f3+f4))/hessIncrement/hessIncrement/4.0;%B(_q,(2iwIn-A)_1*B(q,q))
  x1 = x0 + hessIncrement*(conj(q)+q);
  x2 = x0 - hessIncrement*(conj(q)+q);
  x3 = x0 + hessIncrement*(conj(q)-q);
  x4 = x0 - hessIncrement*(conj(q)-q);
  f1 = feval(odefile, 0, x1, p1{:});
  f2 = feval(odefile, 0, x2, p1{:});
  f3 = feval(odefile, 0, x3, p1{:});
  f4 = feval(odefile, 0, x4, p1{:});
  h2 = ((f1+f2)-(f3+f4))/hessIncrement/hessIncrement/4.0;%B(_q,q)
  h2 = jac\ h2;						 %A_1*B(_q,q)
  x1 = x0 + hessIncrement*(h2+q);
  x2 = x0 - hessIncrement*(h2+q);
  x3 = x0 + hessIncrement*(h2-q);
  x4 = x0 - hessIncrement*(h2-q);
  f1 = feval(odefile, 0, x1, p1{:});
  f2 = feval(odefile, 0, x2, p1{:});
  f3 = feval(odefile, 0, x3, p1{:});
  f4 = feval(odefile, 0, x4, p1{:});
  h2 = ((f1+f2)-(f3+f4))/hessIncrement/hessIncrement/4.0;%B(q,A_1*B(_q,q))			
  ten3Increment =(cds.options.Increment)^(3.0/6.0);
  x1 = x0 + 3.0*ten3Increment*conj(q);
  x2 = x0 +     ten3Increment*conj(q);
  x3 = x0 -     ten3Increment*conj(q);
  x4 = x0 - 3.0*ten3Increment*conj(q);
  f1 = feval(odefile, 0, x1, p1{:});
  f2 = feval(odefile, 0, x2, p1{:});
  f3 = feval(odefile, 0, x3, p1{:});
  f4 = feval(odefile, 0, x4, p1{:});
  h3 = (f1 - 3.0*f2 + 3.0*f3 - f4)/ten3Increment/ten3Increment/ten3Increment/8.0; % C(_q,_q,_q);
  x1 = x0 + 3.0*ten3Increment*(q-conj(q));
  x2 = x0 +     ten3Increment*(q-conj(q));
  x3 = x0 -     ten3Increment*(q-conj(q));
  x4 = x0 - 3.0*ten3Increment*(q-conj(q));
  f1 = feval(odefile, 0, x1, p1{:});
  f2 = feval(odefile, 0, x2, p1{:});
  f3 = feval(odefile, 0, x3, p1{:});
  f4 = feval(odefile, 0, x4, p1{:});
  h4 = (f1 - 3.0*f2 + 3.0*f3 - f4)/ten3Increment/ten3Increment/ten3Increment/8.0; % C(q-_q,q-_q,q-_q);
  x1 = x0 + 3.0*ten3Increment*(q+conj(q));
  x2 = x0 +     ten3Increment*(q+conj(q));
  x3 = x0 -     ten3Increment*(q+conj(q));
  x4 = x0 - 3.0*ten3Increment*(q+conj(q));
  f1 = feval(odefile, 0, x1, p1{:});
  f2 = feval(odefile, 0, x2, p1{:});
  f3 = feval(odefile, 0, x3, p1{:});
  f4 = feval(odefile, 0, x4, p1{:});
  h5 = (f1 - 3.0*f2 + 3.0*f3 - f4)/ten3Increment/ten3Increment/ten3Increment/8.0; % C(q+_q,q+_q,q+_q);
  fl = real(p'*((h5-h4)/6.0 - h3/3.0 - 2.0*h2 +h1))/2;
% end
%notice vector' is the transposed and conjugated=Hermitian!!
%  hessIncrement =(cds.options.Increment)^(3.0/4.0);
%  x2 = x1 + hessIncrement*q;
%  f1 = feval(odefile, 0, x2, p1{:});
