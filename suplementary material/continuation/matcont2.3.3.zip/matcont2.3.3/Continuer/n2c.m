function c = n2c(n)

for i=1:length(n)
  c{i} = n(i);
end
