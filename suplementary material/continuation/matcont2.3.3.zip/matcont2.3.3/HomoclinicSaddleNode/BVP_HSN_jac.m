% Builds up jacobian of boundary value problem
%
% ============================================

function result = BVP_HSN_jac(odefile1,x,x0,p,T,eps0,eps1,YS,YU)

global hsnds

ups = reshape(x,hsnds.nphase,hsnds.tps);
p = num2cell(p);

if hsnds.extravec(1)
    Tvar = 1;
    pars = (0:2)+hsnds.PeriodIdx +1;
else
    Tvar = 0;
    pars = (0:1)+hsnds.PeriodIdx +1;
end
tmpperiod = 2 * T;

% Allocate space for sparse jacobian
result = spalloc(hsnds.ncoords+1+hsnds.Ysize+hsnds.nphase+2,...
    hsnds.ncoords+hsnds.nphase+2+sum(hsnds.extravec)+hsnds.Ysize,(hsnds.ncoords+1)^2);
range1 = hsnds.cols_p1;
range2 = 1:hsnds.ncol*hsnds.nphase;
range3 = 1:(hsnds.ncol+1)*hsnds.nphase;

% Component 1
% ===========
for i=hsnds.tsts
    range4 = hsnds.phases;
    % value of polynomial in each mesh point
    xval = ups(:,range1) * hsnds.wt;
    wploc = hsnds.wp/hsnds.dt(i);
    % evaluate part of Jacobian matrix
    for j=hsnds.cols
        xtmp = xval(:,j);
        if Tvar
            frhs(range4) = feval(odefile1, 0, xtmp, p{:});
        end
        jac=HSN_odejac(xtmp,p);
        jacp = HSN_odejacp(xtmp,p);
        sysjac(range4,:) = fastkron(hsnds.ncol,hsnds.nphase,hsnds.wt(:,j)',jac);
        sysjacp(range4,:) = jacp(:,hsnds.ActiveParams);
        
        range4 = range4+hsnds.nphase;
    end
    % Store result
    if Tvar 
        result(range2,[range3 pars]) = [wploc-tmpperiod*sysjac    -tmpperiod*sysjacp    -2*frhs'];
    else
        result(range2,[range3 pars]) = [wploc-tmpperiod*sysjac    -tmpperiod*sysjacp];
    end    
    % shift to following intervals
    range1 = range1 + hsnds.ncol;
    range2 = range2 + hsnds.ncol*hsnds.nphase;
    range3 = range3 + hsnds.ncol*hsnds.nphase;
end

% Component 2 (equilibrium)
% ===========
result(hsnds.ncoords-hsnds.nphase+1:hsnds.ncoords, hsnds.ncoords+1:hsnds.ncoords+hsnds.nphase) = HSN_odejac(x0,p);
tmp1 = HSN_odejacp(x0,p);
tmp1 = tmp1(:,hsnds.ActiveParams);
result(hsnds.ncoords-hsnds.nphase+1:hsnds.ncoords,  hsnds.ncoords+hsnds.nphase+1:hsnds.ncoords+hsnds.nphase+2) = tmp1;

% Component 2bis (limit point)
% ==============
  jac = HSN_odejac(x0,p);
  Bord = [jac hsnds.wvector;...
        hsnds.vvector' 0];
  bunit = [zeros(hsnds.nphase,1);1];
  vext = Bord \ bunit;
  wext = Bord' \ bunit;
  tmp = HSN_odejacp(x0,p);
  jac = [jac tmp(:,hsnds.ActiveParams)]; 
  hess = HSN_odehess(x0,p);
  for i=1:hsnds.nphase
      jac(hsnds.nphase+1,i)=-wext(1:hsnds.nphase)'*hess(:,:,i)*vext(1:hsnds.nphase);
  end
  hessp = HSN_odehessp(x0,p);
  for i=1:length(hsnds.ActiveParams);
      jac(hsnds.nphase+1,hsnds.nphase+i)=-wext(1:hsnds.nphase)'*hessp(:,:,i)*vext(1:hsnds.nphase);
  end
  result(hsnds.ncoords+1,hsnds.ncoords+1:hsnds.ncoords+hsnds.nphase+2) = jac(end,:);

% Component 3 (phase condition)
% ===========
range1 = hsnds.cols_p1;
range3 = 1:(hsnds.ncol+1)*hsnds.nphase;
icjac = zeros(1,hsnds.ncoords);
for i=1:hsnds.ntst
    tmp = hsnds.dt(i)*(hsnds.upoldp(:,range1) .* hsnds.pwi);
    icjac(range3) = icjac(range3) + tmp(1:(hsnds.ncol+1)*hsnds.nphase);
    
    range1 = range1 + hsnds.ncol;
    range3 = range3 + hsnds.ncol*hsnds.nphase;
end
result(hsnds.ncoords+2,[hsnds.coords]) = icjac;


% Component 4 (Eigenspaces)
% ===========
Q0U = hsnds.oldUnstableQ;
Q0S = hsnds.oldStableQ;
hess = HSN_odehess(x0,p);
hessp = HSN_odehessp(x0,p);
for j=1:hsnds.nphase+2
    if j<=hsnds.nphase
        Atemp = hess(:,:,j);
    else
        Atemp = hessp(:,:,j-hsnds.nphase);
    end    
    if ~isempty(YU)
        [U11, U12, UE21, U22] = ricattiCoeff(Q0U,Atemp,hsnds.npos);
        tmp = (U22*YU - YU*U11 + UE21 - YU*U12*YU)';
        for i=1:hsnds.nneg+1
            result(hsnds.ncoords+2+1:hsnds.ncoords+2+1+hsnds.npos*(hsnds.nneg+1),hsnds.ncoords+j) = tmp(:,i);
        end    
    end
    if ~isempty(YS)
        [S11, S12, SE21, S22] = ricattiCoeff(Q0S,Atemp,hsnds.nneg);
        tmp = (S22*YS - YS*S11 + SE21 - YS*S12*YS)';
        for i=1:hsnds.npos+1
            result(hsnds.ncoords+2+hsnds.npos*(hsnds.nneg+1)+1:hsnds.ncoords+2+hsnds.npos*(hsnds.nneg+1)+hsnds.nneg*(hsnds.npos+1),hsnds.ncoords+j) = tmp(:,i);
        end
    end
end

% UNSTABLE
% Riccati blocks from unstable eigenspace
A=HSN_odejac(x0,p);
derU = [];
if ~isempty(YU)
    [U11, U12, UE21, U22] = ricattiCoeff(Q0U,A,hsnds.npos);
    U12Y = U12 * YU;
    YU12 = YU * U12;
end
for j=1:hsnds.npos
    for i=1:hsnds.nneg+1
        myres = sparse(hsnds.nneg+1,hsnds.npos,0);
        myres(:,j) = myres(:,j) + U22(:,i);
        myres(i,:) = myres(i,:) - U11(j,:);        
        myres(i,:) = myres(i,:) - U12Y(j,:);
        myres(:,j) = myres(:,j) - YU12(:,i);        
        % Derivative is computed to YU(i,j) i=1:hsnds.nneg j=1:hsnds.npos
        % must come at column (j-1)*(hsnds.nneg)+i, 
        % in form T and col-first == row-first
        rows = size(myres,1);
        cols = size(myres,2);
        for k=1:rows
            derU((k-1)*cols+1:k*cols,(j-1)*(hsnds.nneg+1)+i) = myres(k,:)';
        end
    end
end

% STABLE
derS = [];
if ~isempty(YS)
    [S11, S12, SE21, S22] = ricattiCoeff(Q0S,A,hsnds.nneg);
    S12Y = S12 * YS;
    YS12 = YS * S12;
end
for i=1:hsnds.npos+1
    for j=1:hsnds.nneg
        myres = sparse(hsnds.npos+1,hsnds.nneg,0);
        myres(:,j) = myres(:,j) + S22(:,i);
        myres(i,:) = myres(i,:) - S11(j,:);
        myres(i,:) = myres(i,:) - S12Y(j,:);
        myres(:,j) = myres(:,j) - YS12(:,i);        
        % Derivative is computed to YS(i,j)
        % must come at column (j-1)*(hsnds.npos)+i, 
        % in form T and col-first == row-first
        rows = size(myres,1);
        cols = size(myres,2);
        for k=1:rows
            derS((k-1)*cols+1:k*cols,(j-1)*(hsnds.npos+1)+i) = myres(k,:)';
        end
    end
end
result(hsnds.ncoords+2+1:hsnds.ncoords+2+hsnds.npos*(hsnds.nneg+1),end-hsnds.Ysize+1:end-(hsnds.npos+1)*(hsnds.nneg)) = derU;
result(hsnds.ncoords+2+hsnds.npos*(hsnds.nneg+1)+1:hsnds.ncoords+2+hsnds.Ysize,end-(hsnds.npos+1)*(hsnds.nneg)+1:end) = derS;


% Component 5 (Last and first vectors along stable and unstable eigenspaces)
% ===========
A=HSN_odejac(x0,p);
opt.disp = 0;
%  [V,D] = eigs(A,1,'SM',opt);
%  [W,D] = eigs(A',1,'SM',opt);
[V,D] = eig(A);
[Y,i] = min(abs(diag(D)));
V = V(:,i);
[W,D] = eig(A');
[Y,i] = min(abs(diag(D)));
W = W(:,i);
D = D(i,i);

almostA = A - D * eye(size(A));
bigMat = [almostA W; V' 0];
hessx = HSN_odehess(x0,p);
hessp = HSN_odehessp(x0,p);
for i=1:hsnds.nphase
    dlambdadx = (W' * hessx(:,:,i) * V) / (W' * V);
    rhs = -hessx(:,:,i) * V + dlambdadx * V;
    dVdxg = bigMat \ [rhs ;0];
    dV(:,i) = dVdxg(1:end-1,1);
end
for i=1:length(hsnds.ActiveParams)
    dlambdadp = (W' * hessp(:,:,i)  * V) / (W' * V);
    rhs2 = -hessp(:,:,i) * V + dlambdadp * V;
    dVdpg = bigMat \ [rhs2 ;0];
    dV(:,hsnds.nphase+i) = dVdpg(1:end-1,1);
end

if hsnds.nneg
    indxs = [1:hsnds.nphase   hsnds.ncoords+1:hsnds.ncoords+hsnds.nphase];
    vect = ups(:,1) - x0;
    if hsnds.npos
        Q1U = Q0U * [eye(size(YU,1)); YU];
    else
        Q1U = [];
    end;
    
    [Q,R] = qr(V);
    for j=1:hsnds.nneg
        dQtot{j} = [];
    end
    for i=1:hsnds.nphase+2
        Qdv = (Q' * dV(:,i));
        Qdv = tril(Qdv,-1);
        B = Qdv / R;
        B = tril(B) - tril(B)';
        dQ = Q * B;
        for j=1:hsnds.nneg            
            tmp = dQtot{j};
            dQtot{j} = [tmp dQ(:,end-j+1)];
        end
    end    
    
     myA = [Q1U V];
     [Qn,Rn] = qr(myA);
     
    vQ = -vect' * [Q0U V];
    
    for i=1:hsnds.nneg
        result(end-1-hsnds.npos-hsnds.nphase+i,indxs) = [Qn(:,end-i+1)'     -Qn(:,end-i+1)'];
    end
    for i=1:hsnds.nneg
        vQb = vect' * dQtot{i};
        result(end-1-hsnds.npos-hsnds.nphase+i,hsnds.ncoords+1:hsnds.ncoords+hsnds.nphase+2) = ...
            result(end-1-hsnds.npos-hsnds.nphase+i,hsnds.ncoords+1:hsnds.ncoords+hsnds.nphase+2) + ...
            vQb;
    end
    if hsnds.npos
        for j=1:hsnds.npos+1
            result(end-hsnds.nphase-hsnds.npos:end-hsnds.nphase-hsnds.npos-1+hsnds.nneg,end-hsnds.Ysize+(j-1)*(hsnds.npos)+1:end-hsnds.Ysize+j*(hsnds.npos)) = vQ(:,j) .* eye(hsnds.nneg);
        end
    end
end

if hsnds.npos
    indxs = [hsnds.ncoords-hsnds.nphase+1:hsnds.ncoords+hsnds.nphase];
    vect = ups(:,end) - x0;
    if hsnds.nneg
        Q1S = Q0S * [eye(size(YS,1)); YS];
    else 
        Q1S = [];
    end
    [Q,R] = qr(V);
    for j=1:hsnds.npos
        dQtot{j} = [];
    end
    for i=1:hsnds.nphase+2
        Qdv = (Q' * dV(:,i));
        Qdv = tril(Qdv,-1);
        B = Qdv / R;
        B = tril(B) - tril(B)';
        dQ = Q * B;
        for j=1:hsnds.npos            
            tmp = dQtot{j};
            dQtot{j} = [tmp dQ(:,end-j+1)];
        end
    end   
    
    myA = [Q1S V];
    [Qn,Rn] = qr(myA);
    vQ = -vect' * Q0S;    
    
    for i=1:hsnds.npos
        result(end-hsnds.nphase-hsnds.npos+hsnds.nneg+i,indxs) = [Qn(:,end-i+1)'     -Qn(:,end-i+1)'];
    end
    for i=1:hsnds.npos
        vQb = vect' * dQtot{i};
        result(end-hsnds.nphase-hsnds.npos+hsnds.nneg+i,hsnds.ncoords+1:hsnds.ncoords+hsnds.nphase+2) = ...
            result(end-hsnds.nphase-hsnds.npos+hsnds.nneg+i,hsnds.ncoords+1:hsnds.ncoords+hsnds.nphase+2) + ...
           vQb;
    end    
    if hsnds.nneg
        for j=1:hsnds.nneg+1
            result(end-hsnds.nphase-hsnds.npos+hsnds.nneg:end-2,end-(hsnds.npos+1)*(hsnds.nneg)+(j-1)*hsnds.npos+1:end-(hsnds.npos+1)*(hsnds.nneg)+j*hsnds.npos) = vQ(:,j) * eye(hsnds.nneg);
        end
    end
end

% Component 6 (Distances from endpoints to equilibrium equal to epsilons)
% ===========
    indxs = [hsnds.phases   hsnds.ncoords+1:hsnds.ncoords+hsnds.nphase];
    val = ups(:,1) - x0;
    val = val' / norm(val);
    result(end-1,indxs) = [val   -val];
    if hsnds.extravec(2)
        result(end-1,hsnds.ncoords+hsnds.nphase+3+hsnds.extravec(1)) = -1;
    end
    
    indxs = [hsnds.ncoords-hsnds.nphase+1:hsnds.ncoords+hsnds.nphase];
    val = ups(:,end) - x0;
    val = val' / norm(val);
    result(end,indxs) = [val   -val];
    if hsnds.extravec(3)
        result(end,hsnds.ncoords+hsnds.nphase+3+sum(hsnds.extravec(1:2))) = -1;
    end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function K = fastkron(c,p,A,B)
t = p:((c+2)*p-1);
K = A(ones(1,p),fix(t/p)).*B(:,rem(t,p)+1);
