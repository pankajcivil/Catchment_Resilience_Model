function h=bphessbr(x,p)
global bpds cds

if cds.options.SymDerivativeP >= 2
  h = feval(bpds.HessiansP, 0, x, p{:});
  h = h(:,:,bpds.BranchParam);
else
  for i=bpds.BranchParam
    p1 = p; p1{i} = p1{i}-cds.options.Increment;
    p2 = p; p2{i} = p2{i}+cds.options.Increment;
    h(:,:,1) = bpjac(x,p2)-bpjac(x,p1);
  end
  h = h(:,:,1)/(2*cds.options.Increment);
end
