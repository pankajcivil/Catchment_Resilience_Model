function h=HSN_odehessp(x,p)%dxdp
global hsnds cds

if cds.options.SymDerivativeP >= 2
  h = feval(hsnds.HessiansP, 0, x, p{:});
  h = h(:,:,hsnds.ActiveParams);
else
  for i=hsnds.ActiveParams
    p1 = p; p1{i} = p1{i}-cds.options.Increment;
    p2 = p; p2{i} = p2{i}+cds.options.Increment;
    h(:,:,i) = HSN_odejac(x,p2)-HSN_odejac(x,p1);
  end
  h = h(:,:,hsnds.ActiveParams)/(2*cds.options.Increment);
end
