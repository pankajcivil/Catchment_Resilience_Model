function h=htens3(x,p)
global hds cds
if cds.options.SymDerivative >= 3
    h = feval(hds.Der3, 0, x, p{:});
else
    for i=1:hds.nphase
        x1 = x; x1(i) = x1(i)-cds.options.Increment;
        x2 = x; x2(i) = x2(i)+cds.options.Increment;
        h(:,:,:,i) = hhess(x2,p)-hhess(x1,p);
    end
    h = h/(2*cds.options.Increment);
end
