function h=Hom_odehessp(x,p)%dxdp
global homds cds

if cds.options.SymDerivativeP >= 2
  h = feval(homds.HessiansP, 0, x, p{:});
  h = h(:,:,homds.ActiveParams);
else
  for i=homds.ActiveParams
    p1 = p; p1{i} = p1{i}-cds.options.Increment;
    p2 = p; p2{i} = p2{i}+cds.options.Increment;
    h(:,:,i) = Hom_odejac(x,p2)-Hom_odejac(x,p1);
  end
  h = h(:,:,homds.ActiveParams)/(2*cds.options.Increment);
end
