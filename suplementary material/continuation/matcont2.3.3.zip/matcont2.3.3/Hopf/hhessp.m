function h=hhessp(x,p)
global hds cds

if cds.options.SymDerivativeP >= 2
  h = feval(hds.HessiansP, 0, x, p{:});
  h = h(:,:,hds.ActiveParams);
else
  for i=hds.ActiveParams
    p1 = p; p1{i} = p1{i}-cds.options.Increment;
    p2 = p; p2{i} = p2{i}+cds.options.Increment;
    h(:,:,i) = hjac(x,p2)-hjac(x,p1);
  end
  h = h(:,:,hds.ActiveParams)/(2*cds.options.Increment);
end
