function result=htest(x)
%
% [x1,v1] = lcinit_Hopf(odefile,x,v,s,ap,ntst,ncol)
%
% Initializes a Hopf bifurcation continuation from a Hopf point
% detected by a previous equilibrium curve continuation.
%
global cds eds
[x1,p] =rearr(x);p1 = n2c(p);
jac= hjac(x1,p1);
nphase = size(x1,1);
% calculate eigenvalues and eigenvectors
[V,D] = eig(jac);
% find pair of complex eigenvalues
d = diag(D);
smallest_sum = Inf;
for j=1:nphase-1
  [val,idx] = min(abs(d(j+1:nphase)+d(j)));
  if val < smallest_sum
    idx1 = j;
    idx2 = j+idx;
    smallest_sum = val;
  end
end
% real part? Oh dear, a neutral saddle!
if imag(d(idx1)) == 0 & imag(d(idx2)) == 0
  debug('Neutral saddle\n');
  return;
end
[Q,R]=qr([real(V(:,idx1)) imag(V(:,idx1))]);
borders.v=Q(:,1:2);
[V,D] = eig(jac');
% find pair of complex eigenvalues
d = diag(D);
smallest_sum = Inf;
for j=1:nphase-1
  [val,idx] = min(abs(d(j+1:nphase)+d(j)));
  if val < smallest_sum
    idx1 = j;
    idx2 = j+idx;
    smallest_sum = val;
  end
end
[Q,R]=qr([real(V(:,idx1)) imag(V(:,idx1))]);
borders.w=Q(:,1:2);
k=real(d(idx1)*d(idx2));
% calculate eigenvalues
% ERROR OR WARNING
RED=jac*jac+k*eye(nphase);
jacp=hjacp(x1,p1);
A=[jac  jacp zeros(nphase,1)];
[Q,R]=qr(A');
Bord=[RED borders.w;borders.v' zeros(2)];
bunit=[zeros(nphase,2);eye(2)];
vext=Bord\bunit;
wext=Bord'\bunit;
omega=sqrt(k);
alpha=vext(1:nphase,1)'*jac*vext(1:nphase,2)-1i*omega*vext(1:nphase,1)'*vext(1:nphase,2);
beta=-vext(1:nphase,1)'*jac*vext(1:nphase,1)+1i*omega*vext(1:nphase,1)'*vext(1:nphase,1);
q=alpha*vext(1:nphase,1)+beta*vext(1:nphase,2);
alpha=wext(1:nphase,1)'*jac'*wext(1:nphase,2)+1i*omega*wext(1:nphase,1)'*wext(1:nphase,2);
beta=-wext(1:nphase,1)'*jac'*wext(1:nphase,1)-1i*omega*wext(1:nphase,1)'*wext(1:nphase,1);
p=alpha*wext(1:nphase,1)+beta*wext(1:nphase,2);
q=q/norm(q);
p=p/(q'*p);
t1=0;
for i=1:nphase        
    x1 = x0; x1(i) = x1(i)-cds.options.Increment;
    x2 = x0; x2(i) = x2(i)+cds.options.Increment;
    h= hhess(x2,p1);v2=Hessvect(q,q,h);
    h= hhess(x1,p1);v1=Hessvect(q,q,h);
    vi=(v2-v1)/(2*cds.options.Increment);
    t1 = t1+conj(q(i))*vi;
end
test=Hessvect(q,conj(q),hess);%B(q,_q)
test=jac\test;      %A^(-1)*B(q,_q)   
t2=Hessvect(q,test,hess);   %B(q,A^(-1)*B(q,_q))    
test=Hessvect(q,q,hess);  %B(q,q)      
test=(2i*omega*eye(hds.nphase)-jac)\test;%(2iwIn-A)_1*B(q,q)      
t3=Hessvect(conj(q),test,hess);%B(_q,(2iwIn-A)_1*B(q,q))
result=real(p'*(t1-2*t2+t3)); 
      

% ---------------------------------------------------------------
function [x,p] = rearr(x0)
% [x,p] = rearr(x0)
% Rearranges x0 into coordinates (x) and parameters (p)
global cds eds
p = eds.P0;
p(eds.ActiveParams) = x0(end);
x = x0(1:end-1);