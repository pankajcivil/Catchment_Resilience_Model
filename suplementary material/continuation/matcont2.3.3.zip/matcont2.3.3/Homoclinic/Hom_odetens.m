function h=Hom_odetens(x,p)
global homds cds

if cds.options.SymDerivative >= 3
  h = feval(homds.Der3, 0, x, p{:});
else
  for i=homds.phases
    x1 = x; x1(i) = x1(i)-cds.options.Increment;
    x2 = x; x2(i) = x2(i)+cds.options.Increment;
    h(:,:,:,i) = Hom_odehess(x2,p)-Hom_odehess(x1,p);
  end
  h = h/(2*cds.options.Increment);
end
