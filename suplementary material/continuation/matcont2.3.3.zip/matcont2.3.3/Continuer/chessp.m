function h=chessp(odefile,jacobianp,hessiansp,x,p,ap)
global cds

if cds.options.SymDerivativeP >= 2
  h = feval(hessiansp, 0, x, p{:});
  h = h(:,:,ap);
else
  for i=ap
    p1 = p; p1{i} = p1{i}-cds.options.Increment;
    p2 = p; p2{i} = p2{i}+cds.options.Increment;
    h(:,:,i) = cjac(odefile,jacobianp,x,p2)-cjac(odefile,jacobianp,x,p1);
  end
  h = h(:,:,ap)/(2*cds.options.Increment);
end
