function h=bphess(x,p)
global bpds cds

if (cds.options.SymDerivative >=2)
  h = feval(bpds.Hessians, 0, x, p{:});
else
  for i=1:bpds.nphase
    x1 = x; x1(i) = x1(i)-cds.options.Increment;
    x2 = x; x2(i) = x2(i)+cds.options.Increment;
    h(:,:,i) = bpjac(x2,p)-bpjac(x1,p);
  end
  h = h/(2*cds.options.Increment);
end
