function a=nf_lp(odefile,jacobian,hessians,x,p,vext,wext,nphase)
%
% a= nf_lp(odefile,jacobian,hessians,x,p,vext,wext,nphase)
% compute fold normal form coefficient.
%
global eds cds
if cds.options.SymDerivative >= 2
    test=0;
    hess=chess(odefile,jacobian,hessians,x,p);
    for i=1:nphase
      test(i)=wext'*hess(:,:,i)*vext;
    end
    a=(test*vext)/2; 
else
    hessIncrement =(cds.options.Increment)^(3.0/4.0);
    x1 = x - hessIncrement*vext;
    x2 = x + hessIncrement*vext;
    f0 = feval(odefile, 0, x, p{:});
    f1 = feval(odefile, 0, x1, p{:});
    f2 = feval(odefile, 0, x2, p{:});
    a = wext'*(f2+f1-2*f0)/hessIncrement/hessIncrement/2;
end


