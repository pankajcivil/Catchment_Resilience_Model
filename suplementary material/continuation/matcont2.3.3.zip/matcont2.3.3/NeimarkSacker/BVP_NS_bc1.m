% -------------------------------------------------------------
% functions defining the jacobian of the BVP for fold(LPC) bifurcations
% -------------------------------------------------------------

% boundary condition
function bc = BVP_NS_bc1(k)
global lds
bc = [eye(lds.nphase) -2*k*eye(lds.nphase) eye(lds.nphase) lds.NS_psi0(end-lds.nphase+1:end) lds.NS_psi1(end-lds.nphase+1:end)];
