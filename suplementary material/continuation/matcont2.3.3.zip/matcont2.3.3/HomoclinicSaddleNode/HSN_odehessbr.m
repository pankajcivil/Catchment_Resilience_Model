function h=HSN_odehessbr(x,p)
global hsnds cds

if cds.options.SymDerivativeP >= 2
  h = feval(homds.HessiansP, 0, x, p{:});
  h = h(:,:,hsnds.BranchParams);
else
  for i=hsnds.BranchParams
    p1 = p; p1{i} = p1{i}-cds.options.Increment;
    p2 = p; p2{i} = p2{i}+cds.options.Increment;
    h(:,:,i) = HSN_odejac(x,p2)-HSN_odejac(x,p1);
  end
  h = h(:,:,hsnds.BranchParams)/(2*cds.options.Increment);
end
